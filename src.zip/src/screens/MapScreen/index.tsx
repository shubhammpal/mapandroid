import React, { useState, useEffect, useRef, useMemo, useContext } from 'react';
import { View, Text, StyleSheet, StatusBar, TouchableOpacity, Alert, Platform } from 'react-native';
// const MapboxGL = Platform.OS === 'ios' ? require('@react-native-mapbox-gl/maps') : null;
import MapboxGL from '@rnmapbox/maps';
import Geolocation from '@react-native-community/geolocation';
import { ArrowBAckIcon, BackToLocationIcon, CongestionIcon, CrashIcon, DestinationLogo, GarageIcon, HospitalIcon, LaneClosureIcon, LocationIcon, NewGreenOriginIcon, ObjectRoadIcon, RestaurantIcon, RoadworkIcon, StalledVehicleIcon } from '../../assets/svgImg/SvgImg';
import ActionSheet, { ActionSheetRef } from 'react-native-actions-sheet';
import BottomSheet, { BottomSheetHandle, BottomSheetScrollView } from "@gorhom/bottom-sheet";
import { styles } from './styles';
import { useFocusEffect } from '@react-navigation/native';
import { height } from "../../style/typography";
import { COLORS } from '../../style';
import Textinput from '../../component/BottomSheetConatiner/Textinput';
import CategoryList from '../../component/BottomSheetConatiner/CategoryList';
import CategoryConatiner from '../../component/BottomSheetConatiner/CategoryConatiner';
import RecentSearch from '../../component/BottomSheetConatiner/RecentSearch';
import { favRoutesData, recentSearchdata } from '../../component/data/mapdata';
import FavoriteRoutes from '../../component/BottomSheetConatiner/FavoriteRoutes';
import Address from '../../component/BottomSheetConatiner/Address';
import { fetchDirections, requestGetDetails, requestRideHistoryApi, requstImageUploadInSoloRIde } from '../../services/api_Services';
import Directionpinpoints from '../../component/BottomSheetConatiner/Directionpinpoints';
import { MapBox } from './MapBox';
import StartRide from '../../component/BottomSheetConatiner/StartRide';
import StopContainer from '../../component/BottomSheetConatiner/StopContainer';
import { AuthContext } from '../../component/auth/AuthContext';
import ImagePicker from 'react-native-image-crop-picker';
import RideCompleteBox from '../../component/RideCompleteBox/RideCompleteBox';
import axios from 'axios';
import GetLocation from 'react-native-get-location';


export const data = [
  { id: 1, image: <HospitalIcon />, title: 'Hospital' },
  { id: 2, image: <RestaurantIcon />, title: 'Restaurants' },
  { id: 3, image: <GarageIcon />, title: 'Garage' },
]

export const reportData = [
  { id: 1, image: <CrashIcon />, title: 'Crash' },
  { id: 2, image: <CongestionIcon />, title: 'Congestion' },
  { id: 3, image: <RoadworkIcon />, title: 'Roadworkds' },
  { id: 4, image: <LaneClosureIcon />, title: 'Lane Closure' },
  { id: 5, image: <StalledVehicleIcon />, title: 'Stalled Vehicle' },
  { id: 6, image: <ObjectRoadIcon />, title: 'Object on Road' },

]
MapboxGL.setAccessToken('sk.eyJ1IjoiaW5pdHgiLCJhIjoiY2x5cG15cDB2MDJiczJrcXY0NWlrNm9zNiJ9.m6hqEs850sg6Tt0FpERjPg');

const MapScreen = ({ navigation }: any) => {
  if (Platform.OS == 'ios' || Platform.OS =='android') {
    // const [MapboxGL, setMapboxGL] = useState<any>(null);
    // useEffect(() => {
    //   if (Platform.OS === 'ios') {
    //     const loadMapboxGL = async () => {
    //       const MapboxGLModule = await import('@react-native-mapbox-gl/maps');
    //       MapboxGLModule.default.setAccessToken('sk.eyJ1IjoiaW5pdHgiLCJhIjoiY2x5cG15cDB2MDJiczJrcXY0NWlrNm9zNiJ9.m6hqEs850sg6Tt0FpERjPg');
    //       setMapboxGL(() => MapboxGLModule.default);
    //     };
    //     loadMapboxGL();
    //   }
    // }, []);
    const [currentLocation, setCurrentLocation] = useState<any[] | null>(null);
    const [location, setLocation] = useState([0, 0]);
    const [snapPoint, setSnapPoint] = useState(0);
    const actionSheetRef = useRef<ActionSheetRef>(null);
    const sheetRef = useRef<BottomSheet>(null);
    const [screenData, setScreenData] = useState<any>(0);
    const [addressHeight, setAddressHeight] = useState(0);
    const [categoryDataList, setCategoryDataList] = useState();
    const [searchText, setSearchText] = useState<any>();
    const [address, setAddress] = useState('');
    const [getCurrentLocation, setGetCurrentLocation] = useState<any>(location);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [routeNotAvailable, setrouteNotAvailable] = useState<any>(false);
    const [route, setRoute] = useState<any>(null);
    const [endAddress, setEndAddress] = useState<any>();
    const [startAddress, setStartAddress] = useState();
    const [routeData, setRouteData] = useState<any>(null);
    const [distance, setDistance] = useState<any>(0);
    const [duration, setDuration] = useState<any>(0);
    const [avoidRoute, setAvoidRoute] = useState<any>(null);
    const [cameraKey, setCameraKey] = useState(0);
    const [directionRouteDetails, setDirectionRouteDetails] = useState<any>();
    const [traveledPath, setTraveledPath] = useState<any>([]);
    const [finalLoad, setFinalLoad] = useState<boolean>(false);
    const [rideHistoryStartData, setRideHistoryStartData] = useState<any>();
    const [rideUserData, setRideUserData] = useState<any>();
    const [imageAnnotations, setImageAnnotations] = useState<any[]>([]);
    const [destinationArrivedBox, setDestinationArrivedBox] = useState<any>(false);
    const { userToken, userDetails }: any = useContext(AuthContext);
    const ref = useRef();
    const cameraRef = useRef<MapboxGL.Camera>(null);
    const snapPoints = useMemo(
      () =>
        screenData == 0
          ? [
            height / 4,
            height / 7,
            height / 5,
            height / 3,
            height / 1.5,
            height / 1.2,
          ]
          : screenData == 2 ||
            screenData == 1 ||
            screenData == 4
            ? [addressHeight + 60]
            : screenData == 3 ? [addressHeight + 40] : screenData == 5 ? [height / 2] : [addressHeight + 100],
      [screenData, addressHeight],
    );
    useFocusEffect(
      React.useCallback(() => {
        if (screenData == 1) {
          sheetRef.current?.snapToIndex(0);
        } else if (screenData == 2) {
          sheetRef.current?.snapToIndex(0);
        } else if (screenData == 3) {
          sheetRef.current?.snapToIndex(0);
        } else if (screenData == 4 || screenData == 5) {
          sheetRef.current?.snapToIndex(0);
        } else if (screenData == 6) {
          sheetRef.current?.snapToIndex(0);
        }
      }, [screenData]),
    );


    const fetchAddress = async (cordin: any) => {
      const [longitude, latitude] = cordin;
      try {
        const response = await axios.get(`https://api.mapbox.com/geocoding/v5/mapbox.places/${longitude},${latitude}.json?access_token=sk.eyJ1IjoiaW5pdHgiLCJhIjoiY2x5cG15cDB2MDJiczJrcXY0NWlrNm9zNiJ9.m6hqEs850sg6Tt0FpERjPg`);
        const address = response.data.features[0]?.place_name;
        return address
      } catch (error) {
        console.error('Error fetching address:', error);
      }
    };

    useEffect(() => {
      GetUserDetails()
    }, [])

  useEffect(() => {
    GetLocation.getCurrentPosition({
      enableHighAccuracy: true,
      timeout: 60000,
    })
      .then(location => {
        const { latitude, longitude } = location;
          setLocation([longitude, latitude]);
          setGetCurrentLocation({
            latitude,
            longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        
      })
      .catch(error => {
        const { code, message } = error;
        console.warn(code, message);
      })
  }, [])
    useEffect(() => {
      Geolocation.getCurrentPosition(
        position => {
          const { latitude, longitude, heading } = position.coords;
          setLocation([longitude, latitude]);
          setGetCurrentLocation({
            latitude,
            longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });

        },
        error => {
          console.log(error);
        },
        { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000 },
      );
    }, []);

    // useEffect(() => {
    //   const watchId = Geolocation.watchPosition(
    //     position => {
    //       const { latitude, longitude } = position.coords;

    //     },
    //     error => {
    //       console.log(error);
    //     },
    //     { enableHighAccuracy: true, timeout: 15000, maximumAge: 10000, distanceFilter: 10 }
    //   );

    //   return () => Geolocation.clearWatch(watchId);
    // }, []);

    const snapToRoad = async (coordinates: any) => {
      const MAX_COORDINATES_PER_REQUEST = 100;
      const batches = [];
      for (let i = 0; i < coordinates.length; i += MAX_COORDINATES_PER_REQUEST) {
        const batch = coordinates.slice(i, i + MAX_COORDINATES_PER_REQUEST);
        batches.push(batch);
      }

      const snappedCoordinates = [];
      for (const batch of batches) {
        const pathString = batch.map((coord: any) => coord.join(',')).join(';');
        const response = await fetch(`https://api.mapbox.com/matching/v5/mapbox/driving/${pathString}?access_token=sk.eyJ1IjoiaW5pdHgiLCJhIjoiY2x5cG15cDB2MDJiczJrcXY0NWlrNm9zNiJ9.m6hqEs850sg6Tt0FpERjPg&geometries=geojson`);
        const data = await response.json();
        if (data && data.matchings && data.matchings.length > 0) {
          snappedCoordinates.push(...data.matchings[0].geometry.coordinates);
        }
      }

      return snappedCoordinates;
    };

    const handleSubmitPress = async () => {
      setFinalLoad(true)
      const snappedPath = await snapToRoad(traveledPath);

      mainApi(traveledPath, "press")
      // setTraveledPath(snappedPath);
    };

    const handleSubmit = async () => {
      setFinalLoad(true)
      const snappedPath = await snapToRoad(traveledPath);

      mainApi(traveledPath)
      // setTraveledPath(snappedPath);
    };

    const handleFocus = () => {
      sheetRef.current?.snapToIndex(5);
    };
    const handleSheetChange = (index: number) => {
      if (index >= 0 && index < snapPoints.length) {
        setCurrentIndex(index);
      } else {
        console.warn(
          `Invalid index: ${index}. Expected between 0 and ${snapPoints.length - 1
          }`,
        );
      }
    };

    useEffect(() => {
      getDirectionsXustom(currentLocation)
    }, [avoidRoute])

    async function checkBikeRestrictions(steps) {

      for (let step of steps) {
        for (let intersection of step.intersections) {
          const classes = intersection.classes || [];
          if (classes.includes('motorway')) {
            return true; // Bike not allowed
          }
        }
      }

      return false; // Bike allowed
    }

    const getDirections = async (desti: any, address?: any) => {
      if (address) {
        setAddress(address);
      }
      if (desti) {
        const origin = [location[0], location[1]];
        const destination = [desti[0], desti[1]];
        const routeData = await fetchDirections(origin, destination, avoidRoute);

        const steps = routeData.legs[0].steps;

        const bikeStatus = await checkBikeRestrictions(steps)
        if (bikeStatus == true) {
          setAvoidRoute("motorway")

        } else {
          if (routeData) {
            setrouteNotAvailable(true)
            setRouteData(routeData);
            setRoute(routeData?.geometry)
            setDistance((routeData?.distance / 1000).toFixed(2)); // distance in km
            setDuration((routeData?.duration / 60).toFixed(2)); // duration in minutes
            handleFitBounds(desti)
          }

        }

      }
    };


    const getDirectionsXustom = async (desti: any, address?: any) => {
      if (address) {
        setAddress(address);
      }
      if (desti) {
        const origin = [location[0], location[1]];
        const destination = [desti[0], desti[1]];
        const routeData = await fetchDirections(origin, destination, avoidRoute);
        if (routeData) {
          setrouteNotAvailable(true)
          setRouteData(routeData);
          setRoute(routeData?.geometry)
          setDistance((routeData?.distance / 1000).toFixed(2)); // distance in km
          setDuration((routeData?.duration / 60).toFixed(2)); // duration in minutes
          handleFitBounds(desti)
        }
      }
    };

    useEffect(() => {
      if (screenData == 0) {
        setCurrentLocation(null)
        setCameraKey(prevKey => prevKey + 1);
        setRouteData(null)
        setRoute(null)
        setDistance(0)
        setDuration(0)
        setAvoidRoute(null)
      }

    }, [screenData == 0])

    const RouteSet = async () => {
      // setRoute(routeData?.geometry)
      const startAdd = await fetchAddress(location)
      setStartAddress(startAdd)
      handleFitBounds()
      setScreenData(2)
    }

    const handleFitBounds = (desti?: any) => {
      if (cameraRef.current && location && (desti ? desti : currentLocation)) {
        cameraRef.current.fitBounds(
          location,
          desti ? desti : currentLocation,
          desti ? [100, 50, 350, 50] : [240, 50, 300, 50], // Padding: [top, right, bottom, left]
          1000 // Animation duration in milliseconds
        );
      }
    };

    const placesPostData = async () => {
      const apiData = {
        userId: userDetails?.id,
        start: 1
      }
      try {
        await requestRideHistoryApi(apiData)
          .then(async (res: any) => {

            if (res?.status == true) {
              setRideHistoryStartData(res?.payload)
            }
          })
      } catch (error) {
        console.log("Places api response  response: ", error);
      }
    }

    const mainApi = async (resData: any, press?: any) => {
      const formatedistance = `${(directionRouteDetails?.distanceTraveled / 1000).toFixed(4)}`;
      const lastAdress = press ? await fetchAddress(traveledPath[traveledPath.length - 1]) : endAddress;

      try {
        const response = await fetch('http://3.111.234.55:6002/api/map/bike-ride-create', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            userId: userDetails?.id,
            mapApiResponse: [],
            mapFinalResponse: JSON.stringify(resData),
            stop: 1,
            rideId: rideHistoryStartData?._id,
            rideKm: formatedistance,
            startAddress: startAddress,
            endAddress: press ? lastAdress : endAddress,
            ride_point: parseFloat(rideUserData?.settings?.individual_ride_point) * parseFloat(formatedistance)
          }),
        });
        const data = await response.json();
        console.log('API response data:');

        setFinalLoad(false)

        if (!press) {
          setScreenData(5)
        } else{
          setScreenData(0)
        }

      } catch (error) {
        console.error('Error calling API:', error);
        if (!press) {
          setScreenData(5)
        } else{
          setScreenData(0)
        }
        setFinalLoad(false)

      }

    };

    const GetUserDetails = async () => {
      let apiData
      apiData = { user_id: userDetails?.id, token: userToken };

      try {
        const res = await requestGetDetails(apiData);
        console.log(res, 'dattaaaaa')
        if (res?.data) {
          setRideUserData(res?.data)
        }
      } catch (error) {

        console.log('User details response: ', error);
      }
    };

    const handleImagePick = () => {
      setTimeout(() => {
        ImagePicker.openCamera({
          width: 300,
          height: 400,
          cropping: true,
        }).then(image => {

          imageUploadOnRide(image?.path)
          const newAnnotation = {
            coords: [traveledPath[traveledPath.length - 1][0], traveledPath[traveledPath.length - 1][1]], // Replace with the desired coordinates
            imagePath: image?.path,
          };
          setImageAnnotations([...imageAnnotations, newAnnotation]);
        }).catch(error => {
          console.log("Image pick error: ", error);
        });
      }, 500);
    }

    const imageUploadOnRide = async (imageData: any) => {
      const apiData = {
        image: imageData,
        lat: getCurrentLocation?.latitude,
        lng: getCurrentLocation?.longitude,
        rideId: rideHistoryStartData?._id
      }
      try {
        await requstImageUploadInSoloRIde(apiData)
          .then(async (res: any) => {
            console.log(res, 'iiiiiiiiiiiiii')
            if (res?.status == true) {

            }
          })
      } catch (error) {
        console.log("Places api response  response: ", error);
      }
    }
    return (
      <View style={[styles.page, (screenData == 3 || screenData == 4 || screenData == 6) ? {} : {
        justifyContent: 'flex-start',
        alignItems: 'center',
      }]}>

        <StatusBar barStyle={'light-content'} />
        {/* {
          MapboxGL && (
            <> */}
        <>

          {
            screenData == 3 || screenData == 4 || screenData == 6 ? (
              <MapBox setScreenData={setScreenData} origin={location} setDirectionRouteDetails={setDirectionRouteDetails} currentLocation={currentLocation} imageAnnotations={imageAnnotations} setDestinationArrivedBox={setDestinationArrivedBox} handleSubmit={handleSubmit} setTraveledPath={setTraveledPath} />
            ) : (
              <View style={[styles.containerMap, { height: screenData == 2 ? "60%" : "100%" }]}>

                <MapboxGL.MapView
                  style={styles.mapBox}
                // styleURL='mapbox://styles/mapbox/navigation-day-v1'
                >
                  {
                    location && (
                      <>
                        <MapboxGL.Camera
                          zoomLevel={14}
                          centerCoordinate={location}
                          key={cameraKey + 1}
                          ref={cameraRef}
                        />
                        <MapboxGL.PointAnnotation
                          id="userLocation"
                          coordinate={location}
                        >

                          <NewGreenOriginIcon />
                          {/* </View> */}
                        </MapboxGL.PointAnnotation>
                      </>
                    )
                  }
                  {
                    currentLocation && (
                      <>
                        {/* <MapboxGL.Camera
                      zoomLevel={14}
                      centerCoordinate={currentLocation}
                    /> */}
                        <MapboxGL.PointAnnotation
                          id="userLocation"
                          coordinate={currentLocation}
                        >

                          <DestinationLogo />
                          {/* </View> */}
                        </MapboxGL.PointAnnotation>
                      </>
                    )
                  }
                  {route && (
                    <>
                      <MapboxGL.ShapeSource id="routeBorderSource" shape={route}>
                        <MapboxGL.LineLayer
                          id="routeBorder"
                          style={{
                            lineColor: COLORS.black,
                            lineWidth: 6, // The width includes the border width + line width
                            lineOpacity: 1,
                          }}
                        />
                      </MapboxGL.ShapeSource>
                      <MapboxGL.ShapeSource id="routeSource" shape={route}>
                        <MapboxGL.LineLayer id="routeFill" style={{
                          lineColor: COLORS.blue,
                          lineWidth: 4, // The actual line width
                          lineOpacity: 1,
                        }} />
                      </MapboxGL.ShapeSource>
                    </>
                  )}
                  {/* {traveledPath.length > 1 && (
                <MapboxGL.ShapeSource
                  id="traveledPathSource"
                  shape={{
                    type: 'Feature',
                    geometry: {
                      type: 'LineString',
                      coordinates: traveledPath,
                    },
                  }}
                >
                  <MapboxGL.LineLayer
                    id="traveledPathFill"
                    style={{
                      lineColor: 'grey',
                      lineWidth: 3,
                      lineOpacity: 0.8,
                    }}
                  />
                </MapboxGL.ShapeSource>
              )} */}
                  <View style={styles.drawerTopView}>
                    <TouchableOpacity style={[styles.drawer, { alignSelf: 'flex-start', }]} onPress={() => navigation.goBack()}>
                      <ArrowBAckIcon />
                    </TouchableOpacity>

                    <TouchableOpacity style={[styles.locationIcon, { alignSelf: 'flex-start', }]} onPress={() => { setCameraKey(prevKey => prevKey + 1) }}>
                      <BackToLocationIcon />
                    </TouchableOpacity>
                  </View>
                </MapboxGL.MapView>

              </View>
            )
          }

          <BottomSheet
            ref={sheetRef}
            index={0}
            snapPoints={snapPoints}
            backgroundStyle={{ backgroundColor: screenData == 3 || screenData == 4 ? COLORS.whiteOFF : COLORS.black }}
            handleComponent={screenData == 1 || screenData == 3 || screenData == 5 || screenData == 6 ? null : BottomSheetHandle}
            handleIndicatorStyle={styles.handleIndicator}
            onChange={handleSheetChange}
          >
            <View style={[styles.contentContainer, { backgroundColor: screenData == 3 || screenData == 4 ? COLORS.whiteOFF : COLORS.black, }, (screenData == 3) && { borderTopWidth: 2, borderTopColor: COLORS.whiteEB }]}>

              {
                screenData == 0 ? (
                  <BottomSheetScrollView contentContainerStyle={{}} keyboardShouldPersistTaps='always' keyboardDismissMode='on-drag' >
                    <View style={{
                      backgroundColor: '#212121',
                      borderWidth: 1,
                      borderRadius: 12,
                      marginVertical: 20,
                      borderColor: COLORS.offblack43,
                    }}>
                      <Textinput setScreenData={setScreenData} setCurrentLocation={setCurrentLocation} categoryDataList={categoryDataList} setCategoryDataList={setCategoryDataList}
                        getDirections={getDirections} setSearchText={setSearchText} handleFocus={handleFocus}
                        destination={getCurrentLocation} searchText={searchText} ref={ref} setEndAddress={setEndAddress} />
                    </View>
                    {
                      categoryDataList ?
                        <CategoryList setScreenData={setScreenData} setCurrentLocation={setCurrentLocation} getDirections={getDirections} categoryDataList={categoryDataList} latitude={getCurrentLocation?.latitude} setEndAddress={setEndAddress}
                          longitude={getCurrentLocation?.longitude} setCategoryDataList={setCategoryDataList} setSearchText={setSearchText} />
                        : (

                          <>

                            <CategoryConatiner data={data} handleFocus={handleFocus} setScreenData={setScreenData} setCategoryDataList={setCategoryDataList} />

                            <RecentSearch
                              recentData={recentSearchdata}
                              handleFocus={handleFocus}
                              pressing={(data: any) => {

                                let details: any = data;

                                if (
                                  details &&
                                  details.geometry &&
                                  details.geometry.location
                                ) {
                                  const { lat, lng } = details.geometry.location;
                                  setScreenData(1);
                                  setCurrentLocation([lng, lat]);
                                  getDirections([lng, lat], details?.formatted_address);
                                  setEndAddress(details?.formatted_address)
                                } else {
                                  console.warn('No location details available');
                                }
                              }}
                            />
                            {/* <FavoriteRoutes favRoutesData={favRoutesData} /> */}
                          </>
                        )
                    }
                  </BottomSheetScrollView>
                ) : screenData == 1 ? (
                  <Address
                    address={address}
                    distance={distance}
                    setScreenData={setScreenData}
                    setAddressHeight={setAddressHeight}
                    routeNotAvailable={routeNotAvailable}
                    setrouteNotAvailable={setrouteNotAvailable}
                    RouteSet={RouteSet}
                  />
                ) :
                  screenData == 2 ? (
                    <Directionpinpoints
                      setScreenData={setScreenData}
                      setAddressHeight={setAddressHeight}
                      directionData={routeData}
                      setAvoidRoute={setAvoidRoute}
                      startAddress={startAddress}
                      // handleStartButtonClick={() => { setTwoD(!twoD), setIsMapFocusedOnMarker(true), handleStartButtonClick(), placesPostData() }}
                      endAddress={endAddress}
                      handleStartButtonClick={() => { placesPostData() }}
                    />
                  ) : screenData == 3 ? (
                    <StartRide directionRouteDetails={directionRouteDetails} distance={distance} duration={duration} directionData={routeData} setScreenData={setScreenData} setAddressHeight={setAddressHeight} />
                  ) : screenData == 4 ? (
                    <StopContainer
                      setScreenData={setScreenData}
                      setAddressHeight={setAddressHeight}
                      finalLoad={finalLoad}
                      takePhotoFromCamera={handleImagePick}
                      handleApicall2={() => { handleSubmitPress() }}
                    />
                  ) : screenData == 5 ? (
                    <RideCompleteBox setDestinationArrivedBox={setDestinationArrivedBox} setScreenData={setScreenData} point={parseFloat(rideUserData?.settings?.individual_ride_point) * parseFloat(`${(directionRouteDetails?.distanceTraveled / 1000).toFixed(4)}`)} />
                  ) : null
              }
            </View>
          </BottomSheet>
        </>
        {/* {
                destinationArrivedBox == true && (
                  <RideCompleteBox setDestinationArrivedBox={setDestinationArrivedBox} />
                )
              } */}
        {/* </>
          )
        } */}


      </View>
    );
  } else {
    <View>
      <Text>dhdjdjjdjdj</Text>
    </View>
  }

};


export default MapScreen;

// import React, { useCallback, useRef, useMemo, useEffect, useState, useContext } from "react";
// import { StyleSheet, View, Text, Button, TouchableOpacity, PermissionsAndroid, KeyboardAvoidingView, Platform, ActivityIndicator, Dimensions, Alert, Modal, Linking, Image } from "react-native";
// import BottomSheet, { BottomSheetHandle, BottomSheetScrollView } from "@gorhom/bottom-sheet";
// import {
//   AddreportIcon,
//   ArrowBAckIcon,
//   BackToLocationIcon, CongestionIcon, CrashIcon, CrossBorderIcon, DrawerIcon, GarageIcon, HospitalIcon,
//   LaneClosureIcon, LocationIcon, ObjectRoadIcon, PlusIcon, RestaurantIcon, RoadworkIcon, SearchIcon, SearchboxIcon, SmallLocationIcon, StalledVehicleIcon
// } from "../../assets/svgImg/SvgImg";
// import { styles } from "./styles";
// import MapView, { Marker, PROVIDER_GOOGLE, Polyline } from "react-native-maps";
// import GetLocation from "react-native-get-location";
// import { COLORS, ms } from "../../style";
// import CategoryConatiner from "../../component/BottomSheetConatiner/CategoryConatiner";
// import RecentSearch from "../../component/BottomSheetConatiner/RecentSearch";
// import FavoriteRoutes from "../../component/BottomSheetConatiner/FavoriteRoutes";
// import { MAP_KEY } from "../../services/api_helper";
// import { useFocusEffect } from "@react-navigation/native";
// import MapViewDirections from "react-native-maps-directions";
// import { favRoutesData, mapStyle1, recentSearchdata } from "../../component/data/mapdata";
// import Textinput from "../../component/BottomSheetConatiner/Textinput";
// import Address from "../../component/BottomSheetConatiner/Address";
// import Directionpinpoints from "../../component/BottomSheetConatiner/Directionpinpoints";
// import StartRide from "../../component/BottomSheetConatiner/StartRide";
// import StopContainer from "../../component/BottomSheetConatiner/StopContainer";
// import AddReport from "../../component/BottomSheetConatiner/AddReport";
// import Route from "../../component/BottomSheetConatiner/Route";
// import { height } from "../../style/typography";
// import CategoryList from "../../component/BottomSheetConatiner/CategoryList";
// import ImagePicker from 'react-native-image-crop-picker';
// import ImgView from '../../component/ImgView/ImgView';
// import { decodePolyline, dummyaAdd, findNearestPointOnRoute, fonts, getDistanceFromLatLonInKm, interpolatePolyline, renderHtmlCode } from "../../utils/misc";
// import AppText from "../../component/AppText/AppText";
// import DirectionIcon from "./DirectionIcon";
// import Geolocation from "@react-native-community/geolocation";
// import { AuthContext } from "../../component/auth/AuthContext";
// import { requestRideHistoryApi, requstImageUploadInSoloRIde } from "../../services/api_Services";

// import RideCompleteBox from "../../component/RideCompleteBox/RideCompleteBox";
// import { ZoomIn } from "react-native-reanimated";
// import { activateKeepAwake, deactivateKeepAwake } from '@sayem314/react-native-keep-awake';
// import { MapBox } from "./MapBox";

// // import BackgroundGeolocation from "react-native-background-geolocation";

// const width = Dimensions.get('screen').width
// export const data = [
//   { id: 1, image: <HospitalIcon />, title: 'Hospital' },
//   { id: 2, image: <RestaurantIcon />, title: 'Restaurants' },
//   { id: 3, image: <GarageIcon />, title: 'Garage' },
// ]

// export const reportData = [
//   { id: 1, image: <CrashIcon />, title: 'Crash' },
//   { id: 2, image: <CongestionIcon />, title: 'Congestion' },
//   { id: 3, image: <RoadworkIcon />, title: 'Roadworkds' },
//   { id: 4, image: <LaneClosureIcon />, title: 'Lane Closure' },
//   { id: 5, image: <StalledVehicleIcon />, title: 'Stalled Vehicle' },
//   { id: 6, image: <ObjectRoadIcon />, title: 'Object on Road' },

// ]
// const requestLocationPermission = async () => {
//   try {
//     const granted = await PermissionsAndroid.request(
//       PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
//       {
//         title: 'Geolocation Permission',
//         message: 'Can we access your location?',
//         buttonNeutral: 'Ask Me Later',
//         buttonNegative: 'Cancel',
//         buttonPositive: 'OK',
//       },
//     );
//     if (granted === 'granted') {
//       return true;
//     } else {
//       return false;
//     }
//   } catch (err) {
//     return false;
//   }
// };
// const MapScreen = ({ navigation }: any) => {
//   const sheetRef = useRef<BottomSheet>(null);
//   const [routeFinish, setRouteFinish] = useState<any>(false);
//   const [mapStyle, setMapStyle] = useState(mapStyle1);
//   const _map: any = useRef<MapView>(null);
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [categoryDataList, setCategoryDataList] = useState();
//   const [interpolatedRouteCoordinates, setInterpolatedRouteCoordinates] = useState<any[]>([]);
//   const [currentLocation, setCurrentLocation] = useState<any>(null);
//   const [screenData, setScreenData] = useState<any>(0);
//   const [destinationArrivedBox, setDestinationArrivedBox] = useState<any>(false);
//   const [address, setAddress] = useState('');
//   const [directionData, setDirectionData] = useState<any>('');
//   // const snapPoints = useMemo(() => ['65%', ], []);
//   const [addressHeight, setAddressHeight] = useState(0);
//   //BICYCLING  DRIVING TRANSIT WALKING
//   const [mode, setMode] = useState<string | any>("DRIVING");
//   const [alternative, setAlternative] = useState<Boolean>(false);
//   const [avoidStatus, setAvoidStatus] = useState<Boolean>(false);
//   const [avoid, setAvoid] = useState<String>("");
//   const { userToken, userDetails, location }: any = useContext(AuthContext);
//   const [getCurrentLocation, setGetCurrentLocation] = useState<any>(location);
//   const [routeNotAvailable, setrouteNotAvailable] = useState<any>(false);
//   const coveredCoordinates = [];
//   const remainingCoordinates = [];
//   const snapPoints = useMemo(
//     () =>
//       screenData == 0
//         ? [
//           height / 4,
//           height / 7,
//           height / 5,
//           height / 3,
//           height / 1.5,
//           height / 1.2,
//         ]
//         : screenData == 2 ||
//           screenData == 1 ||
//           screenData == 4 ||
//           screenData == 5
//           ? [addressHeight + 60]
//           : screenData == 3 ? [addressHeight + 40] : [addressHeight + 100],
//     [screenData, addressHeight],
//   );

//   // const snapPoints = useMemo(() => (screenData == 0 ? [height / 4, height / 7, height / 5, height / 3, height / 1.5, height / 1.2] :screenData == 2 ? [addressHeight + 60] : screenData == 4 || screenData == 5 ? [addressHeight + 60] : screenData == 6 ? [addressHeight + 100] : screenData == 3 ? [addressHeight + 60] : [addressHeight + 60]), [screenData, addressHeight]);
//   const [distance, setDistance] = useState<any>(0);
//   const [duration, setDuration] = useState<any>(0);
//   const [destination, setDestination] = useState<any[]>([]);
//   const [steps, setSteps] = useState<any[]>([]);
//   const [currentStepIndex, setCurrentStepIndex] = useState(0);
//   const [coveredRoute, setCoveredRoute] = useState<any[]>([]);
//   const [twoD, setTwoD] = useState<boolean>(true);
//   const [waypoints, setWaypoints] = useState<any[]>([]);
//   const [rideHistoryStartData, setRideHistoryStartData] = useState<any>();
//   const [modalVisible, setModalVisible] = useState(false);

//   const [initialPositionMarker, setInitialPositionMarker] = useState<any>(null);
//   const [userPath, setUserPath] = useState<any[]>([]);
//   const [initialPosition, setInitialPosition] = useState<any>({
//     latitude: 20.5937,
//     longitude: 78.9629,
//     latitudeDelta: 1,
//     longitudeDelta: 1,
//   });
//   const [coordinates, setCoordinates] = useState([]);
//   const [isMapFocusedOnMarker, setIsMapFocusedOnMarker] = useState<any>(false);
//   const [pictureOnLastLng, setPictureOnLastLng] = useState<any[]>([]);
//   const [directionRouteDetails, setDirectionRouteDetails] = useState<any>();
//   useFocusEffect(
//     React.useCallback(() => {
//       if (screenData == 1) {
//         sheetRef.current?.snapToIndex(0);
//       } else if (screenData == 2) {
//         sheetRef.current?.snapToIndex(0);
//       } else if (screenData == 3) {
//         sheetRef.current?.snapToIndex(0);
//       } else if (screenData == 4 || screenData == 5) {
//         sheetRef.current?.snapToIndex(0);
//       } else if (screenData == 6) {
//         sheetRef.current?.snapToIndex(0);
//       }
//     }, [screenData]),
//   );
//   useEffect(() => {
//     activateKeepAwake();
//     return () => {

//       deactivateKeepAwake();
//     };
//   }, []);

//   useEffect(() => {
//     GetLocation.getCurrentPosition({
//       enableHighAccuracy: true,
//       timeout: 60000,
//     })
//       .then(location => {
//         const { latitude, longitude } = location;
//         setInitialPosition({
//           latitude,
//           longitude,
//           latitudeDelta: 0.01,
//           longitudeDelta: 0.01,
//         });
//         setGetCurrentLocation({
//           latitude,
//           longitude,
//           latitudeDelta: 0.01,
//           longitudeDelta: 0.01,
//         });
//         setDestination(oldArray => [...oldArray, {
//           latitude,
//           longitude,
//           latitudeDelta: 0.01,
//           longitudeDelta: 0.01,
//         }]);
//         _map.current?.animateCamera({
//           center: {
//             latitude: latitude, // Adjust the offset for keeping the location near the bottom
//             longitude: longitude,
//           },
//           zoom: 18,
//         }, { duration: 1000 });
//       })
//       .catch(error => {
//         const { code, message } = error;
//         console.warn(code, message);
//       })
//   }, [routeFinish])


//   useEffect(() => {
//     if (screenData == 0 && coordinates.length > 0) {
//       EndRideAction()
//     }
//     if (screenData == 3 || screenData == 4 || screenData == 5) {
//       const watchId = Geolocation.watchPosition(
//         position => {
//           const { latitude, longitude, heading } = position.coords;
//           let newLocation = {
//             latitude: latitude,
//             longitude: longitude,
//             latitudeDelta: 0.00005,
//             longitudeDelta: 0.0005,
//             heading: heading
//           }

//           if (latitude && longitude) {
//             if (destination.length > 3) {
//               const distanceBetween = getDistanceFromLatLonInKm(latitude, longitude, destination[destination.length - 4]?.latitude, destination[destination.length - 3]?.longitude);
//               if (distanceBetween >= 0.03) {
//                 newDirectionCalculation()
//               }

//             }
//             const nearestPoint = findNearestPointOnRoute(latitude, longitude, interpolatedRouteCoordinates);
//             if (nearestPoint) {
//               const distanceToPolyline = getDistanceFromLatLonInKm(latitude, longitude, nearestPoint?.latitude, nearestPoint?.longitude);
//               console.log(distanceToPolyline, '454454545454545545')
//               if (distanceToPolyline >= 0.10) {
//                 const newWaypoint = { latitude: newLocation.latitude, longitude: newLocation.longitude };
//                 setWaypoints(prevWaypoints => [...prevWaypoints, newWaypoint]);

//               }
//               if (nearestPoint) {

//                 if (distanceToPolyline <= 0.05) { // Within 50 meters
//                   setInitialPositionMarker(nearestPoint);
//                   setUserPath((prevPath) => [...prevPath, nearestPoint]);
//                 } else { // Outside 50 meters
//                   setInitialPositionMarker(newLocation);
//                   // setUserPath((prevPath) => [...prevPath, { latitude, }]);
//                 }
//               }
//             } else {
//               setInitialPositionMarker(newLocation);
//             }
//             const distanceToPolylineOfendPoint = getDistanceFromLatLonInKm(latitude, longitude, currentLocation?.latitude, currentLocation?.longitude);
//             console.log(distanceToPolylineOfendPoint, 'asdfasdfasdfasdfasdfasddddddd')
//             if (distanceToPolylineOfendPoint <= 0.03) {
//               setDestinationArrivedBox(true)
//               handleApicall2("arrive")
//             }

//             setDestination(oldArray => [...oldArray, newLocation]);
//           }
//           setGetCurrentLocation(newLocation)
//         },
//         error => console.log('Watch position error:', error),
//         { enableHighAccuracy: true, distanceFilter: 10, interval: screenData == 3 || screenData == 4 || screenData == 5 ? 5000 : 10000 }
//       );

//       return () => {
//         Geolocation.clearWatch(watchId);
//       }
//     }
//   }, [isMapFocusedOnMarker, screenData, waypoints]);

//   const EndRideAction = () => {
//     setDistance(0);
//     setDuration(0);
//     setDirectionData(null);
//     setCurrentLocation(null)
//     setCoordinates([]);
//     setMode("DRIVING")
//     setDestination([getCurrentLocation])
//     setSteps([]);  // Update steps when directions are ready
//     setCurrentStepIndex(0)
//     setInterpolatedRouteCoordinates([]);
//     setrouteNotAvailable(false)
//     setPictureOnLastLng([])
//     setIsMapFocusedOnMarker(false)
//     setPictureOnLastLng([])
//     setRouteFinish(!routeFinish)
//     setAvoid('')
//     setAvoidStatus(false)
//     setMode("DRIVING")
//   }




//   useEffect(() => {
//     if (_map.current && getCurrentLocation) {
//       _map.current.animateToRegion({
//         latitude: getCurrentLocation?.latitude,
//         longitude: getCurrentLocation?.longitude,
//         latitudeDelta: 0.00005,
//         longitudeDelta: 0.0005,
//       });
//     }
//   }, []);

//   const handleFocus = () => {
//     sheetRef.current?.snapToIndex(5);
//   };

//   const toggleMapStyle = () => {
//     setMapStyle(prevStyle => (prevStyle.length == 0 ? mapStyle1 : []));
//   };

//   const MyCustomerMarker = () => {
//     return <LocationIcon />;
//   };
//   const ref = useRef();
//   const [searchText, setSearchText] = useState<any>();
//   const handleSheetChange = (index: number) => {
//     if (index >= 0 && index < snapPoints.length) {
//       setCurrentIndex(index);
//     } else {
//       console.warn(
//         `Invalid index: ${index}. Expected between 0 and ${snapPoints.length - 1
//         }`,
//       );
//     }
//   };

//   const getDirections = (address: any) => {

//     setAddress(address);
//   };

//   const onDirectionReady = (result: any) => {
//     setrouteNotAvailable(true)
//     console.log(result.legs[0]?.distance?.text, 'ddddddasiidiiidididid')
//     if (_map.current) {
//       if (waypoints.length == 0) {
//         setDistance(result.legs[0]?.distance?.text);
//         setDuration(result.legs[0]?.duration?.text);
//       }
//       setDirectionData(result);
//       setSteps(result.legs[0].steps);  // Update steps when directions are ready
//       setCurrentStepIndex(0);
//       // console.log(result)
//       console.log(result.legs[0])
//       const steps = result.legs.flatMap((leg: any) => leg.steps.flatMap((step: any) => decodePolyline(step.polyline.points)));
//       if (steps.length > 0) {
//         setCoordinates(steps);
//         const interpolatedPoints = interpolatePolyline(steps, 10); // Adjust 
//         setInterpolatedRouteCoordinates(interpolatedPoints);
//       }
//       handleApiCall(result.legs[0]?.start_location, result.legs[0]?.end_location, result.legs[0]?.end_address, result)

//     }
//   };


//   const handleStartButtonClick = () => {
//     if (Platform.OS == 'android') {
//       _map.current?.animateCamera({
//         center: {
//           latitude: getCurrentLocation?.latitude, // Adjust the offset for keeping the location near the bottom
//           longitude: getCurrentLocation?.longitude,
//         },
//         heading: getCurrentLocation?.heading,
//         zoom: 18,
//         // altitude: 50
//       }, { duration: 1000 });
//     } else {
//       _map.current?.animateCamera({
//         center: {
//           latitude: getCurrentLocation?.latitude, // Adjust the offset for keeping the location near the bottom
//           longitude: getCurrentLocation?.longitude,
//         },
//         heading: getCurrentLocation?.heading,
//         // pitch: twoD ? 0 : 0,
//         zoom: 18,
//         // altitude: 50
//       }, { duration: 1000 });
//     }

//   };

//   const handleMapDrag = () => {
//     setIsMapFocusedOnMarker(false)
//   };
//   useEffect(() => {
//     if (isMapFocusedOnMarker == true) {
//       handleStartButtonClick()
//     }
//   }, [getCurrentLocation]);



//   const takePhotoFromCamera = () => {

//     setTimeout(() => {
//       ImagePicker.openCamera({
//         cropping: false
//       }).then(image => {
//         console.log(image, 'dhdhdh')
//         setPictureOnLastLng(oldPic => [...oldPic, {
//           img: image,
//           latitude: destination[destination.length - 1].latitude,
//           longitude: destination[destination.length - 1].longitude,
//         }])
//         imageUploadOnRide(image?.path)
//         setScreenData(3)
//       });
//     }, 500);
//   }

//   const fitToCordinate = () => {
//     // const zoomOut = () => {

//     // };
//     if (_map.current) {
//       _map.current.getCamera().then((camera: any) => {
//         console.log(camera, 'cameraaaaa')
//         // camera.zoom -= 1; // Decrease the zoom level
//         _map.current.animateCamera({
//           zoom: 10,
//         }, { duration: 500 }); // Animate the camera to the new zoom level
//       });
//     }
//     setTimeout(() => {
//       _map?.current?.fitToCoordinates(coordinates, {
//         edgePadding: {
//           right: 50,  // Increased padding for better fit
//           bottom: 50, // Increased padding for better fit
//           left: 50,   // Increased padding for better fit
//           top: 50,    // Increased padding for better fit
//         },
//       });

//     }, 1000);

//   }

//   useEffect(() => {
//     if (waypoints.length > 0) {
//       newDirectionCalculation()
//     }
//   }, [waypoints])



//   const newDirectionCalculation = async () => {
//     const response = await fetch(`https://maps.googleapis.com/maps/api/directions/json?origin=${getCurrentLocation?.latitude},${getCurrentLocation?.longitude}&destination=${currentLocation?.latitude},${currentLocation?.longitude}&key=${MAP_KEY}`, {
//     });
//     const data = await response.json();
//     if (data) {
//       if (data?.routes[0]) {
//         setDistance(data?.routes[0]?.legs[0]?.distance?.text)
//         setDuration(data?.routes[0]?.legs[0]?.duration?.text)
//       }
//     }
//   };

//   const handleApicall2 = async (status?: any) => {
//     // 22.716453209775512, 75.8554217673727 , 22.725443965768132, 75.8873031779969
//     const waypointsStr = waypoints.map(point => `${point?.latitude},${point?.longitude}`).join('|');
//     let url
//     if (status == "arrive") {
//       url = `https://maps.googleapis.com/maps/api/directions/json?origin=${destination[0]?.latitude},${destination[0]?.longitude}&destination=${currentLocation?.latitude},${currentLocation?.longitude}&waypoints=${waypointsStr}&key=${MAP_KEY}`;
//     } else {
//       url = `https://maps.googleapis.com/maps/api/directions/json?origin=${destination[0]?.latitude},${destination[0]?.longitude}&destination=${destination[destination.length - 1]?.latitude},${destination[destination.length - 1]?.longitude}&waypoints=${waypointsStr}&key=${MAP_KEY}`;
//     }
//     // if(avoid){
//     // 	url+=`&avoid=${avoid}`;
//     // }

//     const response = await fetch(url, {
//     });
//     const data = await response.json();
//     if (data) {
//       if (status == "arrive") {
//         setTimeout(() => {
//           mainApi(data)
//         }, 2000);
//       } else {
//         mainApi(data)
//       }
//     }

//   };

//   const handleApiCall = async (startLocation: any, endLocation: any, address: any, mapApiResponse: any) => {
//     try {
//       const response = await fetch('http://3.111.234.55:6002/api/map/map-line-create', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//         },
//         body: JSON.stringify({
//           startLocation: `${startLocation?.lat},${startLocation?.lng}`,
//           endLocation: `${endLocation?.lat},${startLocation?.lng}`,
//           address,
//           mapApiResponse,
//         }),
//       });

//       const data = await response.json();
//       console.log('API Response:', data);

//     } catch (error) {
//       console.error('Error calling API:', error);

//     }
//   };
// const mainApi = async (resData: any) => {
//   try {
//     const response = await fetch('http://3.111.234.55:6002/api/map/bike-ride-create', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({
//         userId: userDetails?.id,
//         mapApiResponse: [],
//         mapFinalResponse: resData,
//         stop: 1,
//         rideId: rideHistoryStartData?._id
//       }),
//     });
//     console.log(resData, 'asdfasfsdf', rideHistoryStartData)
//     const data = await response.json();
//     console.log('API response data:', data);
//     setScreenData(0)
//     EndRideAction()
//   } catch (error) {
//     console.error('Error calling API:', error);
//     setScreenData(0)
//     EndRideAction()
//   }
// };

//   const placesPostData = async () => {
//     const apiData = {
//       userId: userDetails?.id,
//       start: 1
//     }
//     try {
//       await requestRideHistoryApi(apiData)
//         .then(async (res: any) => {
//           console.log(res, 'fff')
//           if (res?.status == true) {
//             setRideHistoryStartData(res?.payload)
//           }
//         })
//     } catch (error) {
//       console.log("Places api response  response: ", error);
//     }
//   }
//   const imageUploadOnRide = async (imageData: any) => {
//     const apiData = {
//       image: imageData,
//       lat: getCurrentLocation?.latitude,
//       lng: getCurrentLocation?.longitude,
//       rideId: rideHistoryStartData?._id
//     }
//     try {
//       await requstImageUploadInSoloRIde(apiData)
//         .then(async (res: any) => {
//           console.log(res, 'fff')
//           if (res?.status == true) {

//           }
//         })
//     } catch (error) {
//       console.log("Places api response  response: ", error);
//     }
//   }


//   return (
//     <View style={styles.container}>
//       {
//         screenData == 3 || screenData == 4 || screenData == 6 ? (
//           <MapBox origin={destination[0]} setDirectionRouteDetails={setDirectionRouteDetails} currentLocation={currentLocation} />
//         ) : (
//           <MapView
//             onPanDrag={handleMapDrag}
//             provider={PROVIDER_GOOGLE}
//             style={[styles.map, { height: (screenData == 2 || screenData == 6) ? height + 40 - (addressHeight + 60) : "100%" }]}
//             ref={_map}
//             followsUserLocation={isMapFocusedOnMarker}
//             customMapStyle={mapStyle}
//             userInterfaceStyle="dark"
//             initialRegion={initialPosition}
//             pitchEnabled={false}
//             showsUserLocation
//             showsIndoorLevelPicker
//             showsIndoors
//             rotateEnabled={true}
//             // showsMyLocationButton
//             showsPointsOfInterest


//           >{
//               pictureOnLastLng && (
//                 <>
//                   {
//                     pictureOnLastLng.length > 0 && (
//                       <>
//                         {
//                           pictureOnLastLng.map((picItem: any, index: number) => {
//                             return (

//                               <Marker
//                                 key={index}
//                                 style={{ overflow: "visible" }}
//                                 coordinate={{
//                                   latitude: picItem?.latitude,
//                                   longitude: picItem?.longitude,
//                                 }}>
//                                 <View style={{ justifyContent: 'center', alignItems: 'center', marginLeft: index + 35, }}>
//                                   <ImgView height={50} width={50} url={picItem?.img?.path} radius={50} />
//                                   <View style={{ height: 25, width: 3, backgroundColor: COLORS.red }} />
//                                 </View>
//                               </Marker>

//                             )
//                           })
//                         }
//                       </>
//                     )
//                   }
//                 </>
//               )
//             }

//             {
//               getCurrentLocation && (
//                 <Marker
//                   style={{}}
//                   coordinate={{
//                     latitude: getCurrentLocation?.latitude ? getCurrentLocation?.latitude : 0,
//                     longitude: getCurrentLocation?.longitude ? getCurrentLocation?.longitude : 0,
//                   }}

//                 />

//               )
//             }
//             {
//               currentLocation && (
//                 <Marker
//                   coordinate={{
//                     latitude: currentLocation.latitude,
//                     longitude: currentLocation.longitude,
//                   }}>
//                   <MyCustomerMarker />
//                 </Marker>
//               )
//             }
//             {
//               avoidStatus ? (
//                 <>
//                   <MapViewDirections
//                     origin={destination[0]}
//                     destination={currentLocation}
//                     strokeWidth={0}
//                     mode={mode}
//                     optimizeWaypoints={true}
//                     directionsServiceBaseUrl={`https://maps.googleapis.com/maps/api/directions/json?avoid=${avoid}&`}
//                     // strokeColor="pink"
//                     waypoints={waypoints}
//                     apikey={MAP_KEY}
//                     onReady={onDirectionReady}
//                   />


//                 </>
//               ) : (
//                 <MapViewDirections
//                   origin={destination[0]}
//                   destination={currentLocation}
//                   strokeWidth={0}
//                   optimizeWaypoints={true}
//                   directionsServiceBaseUrl="https://maps.googleapis.com/maps/api/directions/json?"
//                   // strokeColor="pink"
//                   waypoints={waypoints}
//                   apikey={MAP_KEY}
//                   onReady={onDirectionReady}

//                 />
//               )
//             }

//             {coordinates.length > 0 && (
//               <>
//                 <Polyline
//                   coordinates={coordinates}
//                   strokeColor="black" // Border color
//                   strokeWidth={screenData == 3 && isMapFocusedOnMarker ? 15 : 12} // Border width (4 + 2 + 2)
//                 />

//                 <Polyline
//                   coordinates={coordinates}
//                   strokeColor={COLORS.green} // Center line color
//                   strokeWidth={screenData == 3 && isMapFocusedOnMarker ? 10 : 4} // Center line width
//                 />
//               </>
//             )}


//             {/* <Polyline coordinates={userPath} strokeWidth={6} strokeColor="grey" /> */}

//           </MapView>
//         )
//       }

//       {/* )} */}
//       <View style={styles.topConatiner}>

//         {
//           (screenData == 3 || screenData == 4 || screenData == 5) ? (
//             <>
//               {steps.length > 0 && (
//                 <View style={{ justifyContent: 'center', width: "100%", alignItems: 'center', alignSelf: 'center', paddingHorizontal: 20 }}>
//                   {/* <View style={styles.upcomingStepContainer}>

//                     <DirectionIcon direction={steps[currentStepIndex].maneuver} />
//                     <View style={{ flex: 1 }}>
//                       <AppText size={25} color="white" family="PoppinsBold" numLines={1} dotMode="tail">{renderHtmlCode(steps[currentStepIndex].html_instructions, "before")}</AppText>
//                       {
//                         renderHtmlCode(steps[currentStepIndex].html_instructions, "after") && (
//                           <AppText size={15} color="white" family="PoppinsRegular" numLines={2} dotMode="tail">{renderHtmlCode(steps[currentStepIndex].html_instructions, "after")}</AppText>
//                         )
//                       }
//                     </View>
//                   </View> */}

//                   {
//                     !isMapFocusedOnMarker && (
//                       <>
//                         <TouchableOpacity style={[styles.locationIcon, { alignSelf: 'flex-end', marginTop: 25, marginRight: -10 }]} onPress={() => { setIsMapFocusedOnMarker(true), handleStartButtonClick() }}>
//                           <BackToLocationIcon />
//                         </TouchableOpacity>

//                       </>
//                     )
//                   }
//                   {
//                     screenData == 4 && (

//                       <TouchableOpacity style={[styles.pictureContainer, { alignSelf: 'flex-end', marginTop: height / 2.6, marginRight: -25 }]} >
//                         <AddreportIcon />
//                         <AppText size={15} color={COLORS.greyAD} family='PoppinsRegular' align='center'>Add a Report</AppText>
//                       </TouchableOpacity>
//                     )
//                   }
//                 </View>
//               )}
//             </>
//           ) : (
//             <View style={styles.drawerTopView}>
//               <TouchableOpacity style={[styles.drawer, { alignSelf: 'flex-start', }]} onPress={() => navigation.goBack()}>
//                 <ArrowBAckIcon />
//               </TouchableOpacity>

//               <TouchableOpacity style={[styles.locationIcon, { alignSelf: 'flex-start', }]} onPress={() => { handleStartButtonClick() }}>
//                 <BackToLocationIcon />
//               </TouchableOpacity>

//             </View>
//           )
//         }

//       </View>

// <BottomSheet
//   ref={sheetRef}
//   index={0}
//   snapPoints={snapPoints}
//   backgroundStyle={styles.bottomSheetContainer}
//   handleComponent={screenData == 1 || screenData == 3 || screenData == 5 || screenData == 6 ? null : BottomSheetHandle}
//   handleIndicatorStyle={styles.handleIndicator}
//   onChange={handleSheetChange}
// >
//   <View style={styles.contentContainer}>

//     {
//       screenData == 0 ? (
//         <BottomSheetScrollView contentContainerStyle={{}} keyboardShouldPersistTaps='always' keyboardDismissMode='on-drag' >
//           <View style={{
//             backgroundColor: '#212121',
//             borderWidth: 1,
//             borderRadius: 12,
//             marginVertical: 20,
//             borderColor: COLORS.offblack43,
//           }}>
//             <Textinput setScreenData={setScreenData} setCurrentLocation={setCurrentLocation} categoryDataList={categoryDataList} setCategoryDataList={setCategoryDataList}
//               getDirections={getDirections} setSearchText={setSearchText} handleFocus={handleFocus}
//               destination={getCurrentLocation} searchText={searchText} ref={ref} />
//           </View>
//           {
//             categoryDataList ?
//               <CategoryList setScreenData={setScreenData} setCurrentLocation={setCurrentLocation} getDirections={getDirections} categoryDataList={categoryDataList} latitude={getCurrentLocation?.latitude}
//                 longitude={getCurrentLocation?.longitude} setCategoryDataList={setCategoryDataList} setSearchText={setSearchText} />
//               : (

//                 <>
//                   {
//                     currentIndex == 5 && (
//                       <CategoryConatiner data={data} handleFocus={handleFocus} setScreenData={setScreenData} setCategoryDataList={setCategoryDataList} />
//                     )
//                   }
//                   <RecentSearch
//                     recentData={recentSearchdata}
//                     handleFocus={handleFocus}
//                     pressing={(data: any) => {
//                       console.log(data)
//                       let details: any = data;

//                       if (
//                         details &&
//                         details.geometry &&
//                         details.geometry.location
//                       ) {
//                         const { lat, lng } = details.geometry.location;
//                         setScreenData(1);
//                         setCurrentLocation({
//                           latitude: lat,
//                           longitude: lng,
//                           // latitude: lat,
//                           // longitude: lng,
//                         });
//                         getDirections(details?.formatted_address);
//                       } else {
//                         console.warn('No location details available');
//                       }
//                     }}
//                   />
//                   <FavoriteRoutes favRoutesData={favRoutesData} />
//                 </>
//               )
//           }
//         </BottomSheetScrollView>
//       ) : screenData == 1 ? (

//         <Address
//           address={address}
//           distance={distance}
//           setScreenData={setScreenData}
//           setAddressHeight={setAddressHeight}
//           fitToCordinate={fitToCordinate}
//           routeNotAvailable={routeNotAvailable}
//           setrouteNotAvailable={setrouteNotAvailable}
//         />
//       ) :
//         screenData == 2 ? (
//           <Directionpinpoints
//             setScreenData={setScreenData}
//             setAddressHeight={setAddressHeight}
//             directionData={directionData}
//             handleStartButtonClick={() => { setTwoD(!twoD), setIsMapFocusedOnMarker(true), handleStartButtonClick(), placesPostData() }}
//           />
// ) : screenData == 3 ? (
//   <StartRide directionRouteDetails={directionRouteDetails} distance={distance} duration={duration} directionData={directionData} setScreenData={setScreenData} setAddressHeight={setAddressHeight} />
// ) : screenData == 4 ? (
//           <StopContainer
//             setScreenData={setScreenData}
//             setAddressHeight={setAddressHeight}
//             takePhotoFromCamera={takePhotoFromCamera}
//             handleApicall2={handleApicall2}
//           />
//         ) : screenData == 5 ? (
//           <AddReport setScreenData={setScreenData} data={reportData} setAddressHeight={setAddressHeight} />
//         ) : screenData == 6 ? (
//           <BottomSheetScrollView scrollEnabled={false}>
//             <Route setAlternative={setAlternative} getCurrentLocation={getCurrentLocation} setDestination={setDestination} setScreenData={setScreenData} setMode={setMode} mode={mode} setAddressHeight={setAddressHeight} directionData={directionData} setAvoid={setAvoid} setAvoidStatus={setAvoidStatus} avoid={avoid} />
//           </BottomSheetScrollView>
//         ) : null
//     }
//   </View>
// </BottomSheet>
// {
//   destinationArrivedBox == true && (
//     <RideCompleteBox setDestinationArrivedBox={setDestinationArrivedBox} EndRideAction={EndRideAction} />
//   )
// }

//     </View >
//   );
// };


// export default MapScreen;