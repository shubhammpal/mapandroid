// import { View, Text, ScrollView, TouchableOpacity, Image, SafeAreaView, ActivityIndicator, Alert, Modal, PermissionsAndroid } from 'react-native';
// import React, { useContext, useEffect, useState } from 'react';
// import { styles } from './styles';
// import FastImage from 'react-native-fast-image';
// import { ArrowBAckIcon, CameraIcon, CamerasIcon, EditIcon, PhotosIcon, SilverMedal } from '../../assets/svgImg/SvgImg';
// import AppText from '../../component/AppText/AppText';
// import { COLORS } from '../../style';
// import StackProfile from './StackProfile';
// import { requestFollowUser, requestGetDetails, requestProfileImage } from '../../services/api_Services';
// import { AuthContext } from '../../component/auth/AuthContext';
// import ImagePicker from 'react-native-image-crop-picker';
// import { strings } from '../../utils/strings';

// type profileProps = {
//   navigation: any,
//   route: any
// }

// const headers = [
//   { id: 1, title: 'My Activities' },
//   { id: 2, title: 'Club' },
//   { id: 3, title: 'Group' }
// ];

// const ProfileScreen = ({ navigation, route }: profileProps) => {
//   const { userProfilePic, userDetails, userToken, authprofile }: any = useContext(AuthContext);
//   const [userdata, setUserdata] = useState<any>();
//   const [loading, setLoading] = useState<boolean>(false);
//   const [status, setStatus] = useState<boolean>(false);
//   const [modalVisible, setModalVisible] = useState(false);
//   const [pic, setPic] = useState<any>();

//   const getCamera = async () => {
//     try {
//       const granted = await PermissionsAndroid.request(
//         PermissionsAndroid.PERMISSIONS.CAMERA,
//         {
//           title: 'Access Camera',
//           message: 'Can we access your camera?',
//           buttonNeutral: 'Ask Me Later',
//           buttonNegative: 'Cancel',
//           buttonPositive: 'OK',
//         },
//       );
//       console.log('Android camera permission result:', granted);

//       if (granted === PermissionsAndroid.RESULTS.GRANTED) {
//         takePhotoFromCamera();
//         setModalVisible(false);
//       } else {
//         console.log('Android camera permission denied');
//       }
//     } catch (error) {
//       console.error('Error requesting Android camera permission:', error);
//     }
//   };

//   useEffect(() => {
//     const unsubscribe = navigation.addListener('focus', () => {
//       if (route?.params?.id) {
//         setLoading(true);
//         if (route?.params?.id == userDetails?.id) {
//           GetUserDetails(userDetails?.id);
//         } else {
//           GetUserDetails(route.params.id);
//         }
//       } else {
//         GetUserDetails(userDetails?.id);
//       }
//     });

//     return unsubscribe;
//   }, [navigation, route, userDetails?.id]);

//   const GetUserDetails = async (userId: string) => {
//     let apiData
//     if (route?.params?.id == userDetails?.id) {
//       apiData = { user_id: userId, token: userToken };
//     } else {
//       apiData = { user_id: userId, token: userToken, loginUserId: userDetails?.id };
//     }
//     try {
//       const res = await requestGetDetails(apiData);
//       setUserdata(res);
//       setStatus(res?.is_following)
//       if (!route?.params?.id) {
//         userProfilePic(res?.data?.profile_picture);
//       }
//       setLoading(false);
//     } catch (error) {
//       console.log('User details response: ', error);
//       setLoading(false);
//     }
//   };

//   const UserFollowApi = async () => {
//     const data: any = {
//       follower_id: userDetails?.id,
//       token: userToken,
//       following_id: route?.params?.id,
//       action: status == true ? 'unfollow' : 'follow',
//     };
//     try {
//       const res = await requestFollowUser(data);
//       setStatus(!status);
//       setUserdata(prevUserdata => {
//         const newFollowerCount = status
//           ? prevUserdata.follower_count - 1
//           : prevUserdata.follower_count + 1;
//         return {
//           ...prevUserdata,
//           follower_count: newFollowerCount,
//         };
//       });

//     } catch (error) {
//       console.log('Follow user response: ', error);
//     }
//   };

//   const takePhotoFromLibray = () => {
//     setTimeout(() => {
//       ImagePicker.openPicker({
//         mediaType: 'photo',
//         cropping: false,
//       }).then(image => {
//         setPic(image?.path);
//         ProfileApi(image?.path);
//       });
//     }, 1000);
//   };
//   const takePhotoFromCamera = () => {
//     setTimeout(() => {
//       ImagePicker.openCamera({
//         mediaType: 'photo',
//         cropping: false,
//       }).then(image => {
//         setPic(image?.path);
//         ProfileApi(image?.path);
//       });
//     }, 500);
//   };
//   const ProfileApi = async (image: any) => {
//     const data: any = {
//       user_id: userDetails?.id,
//       token: userToken,
//       profile_picture: image,
//     };
//     try {
//       await requestProfileImage(data).then(async (res: any) => {
//         console.log(res, 'image')
//       });
//     } catch (error) {
//       console.log('Profile Image response: ', error);
//     }
//   };
//   return (
//     <ScrollView contentContainerStyle={styles.scrollContainer} style={styles.container}>
//       <View style={styles.container}>
//         <View style={{}}>
//           <FastImage
//             style={{ height: 260, width: '100%' }}
//             source={require('../../assets/img/routeVideo.gif')}
//             resizeMode={FastImage.resizeMode.cover}
//           >
//             <SafeAreaView />
//             <View style={styles.arrow}>
//               <View style={{ flexDirection: 'row', alignItems: "center" }}>
//                 <TouchableOpacity onPress={() => navigation.goBack()} style={{ flexDirection: 'row', alignItems: "center" }}>
//                   <ArrowBAckIcon active={COLORS.white} />
//                   <AppText size={20} color={COLORS.white} family='PoppinsBold' horizontal={25}>
//                     {'Profile'}
//                   </AppText>
//                 </TouchableOpacity>
//               </View>
//               {
//                 !loading && (
//                   route?.params?.id && route.params.id !== userDetails?.id && (
//                     <TouchableOpacity style={[styles.join]} onPress={() => {
//                       setStatus(!status)
//                       UserFollowApi()
//                     }}>
//                       <AppText size={14} color={COLORS.white} family='PoppinsSemiB'>
//                         {status == true ? "Following" : "Follow"}
//                       </AppText>
//                     </TouchableOpacity>
//                   )
//                 )
//               }
//             </View>
//             <View style={{ height: 260, width: '100%', position: 'absolute' }} />
//           </FastImage>
//           {
//             loading ? (
//               <View style={{}}>
//                 <ActivityIndicator size="large" color={COLORS.white} />
//               </View>
//             ) : (
//               <View style={styles.imageView}>
//                 <View style={{ flexDirection: 'row', alignItems: 'flex-end', width: '80%' }}>
//                   <View style={{ alignItems: 'center', width: '100%' }}>
//                     <TouchableOpacity style={styles.profileConatiner}
//                       onPress={() => {
//                         setModalVisible(true);
//                       }}>
//                       <FastImage
//                         style={styles.image}
//                         source={pic ?
//                           { uri: pic } :
//                           userdata ?
//                             userdata?.data?.profile_picture ?
//                               { uri: userdata?.data?.profile_picture } :
//                               require('../../assets/img/Person1.png') :
//                             authprofile ?
//                               { uri: authprofile } :
//                               require('../../assets/img/Person1.png')
//                         }
//                       />

//                       {
//                         !route?.params?.id && (
//                           <TouchableOpacity style={styles.editContainer}
//                             onPress={() => {
//                               setModalVisible(true);
//                             }}>
//                             <CameraIcon />
//                           </TouchableOpacity>
//                         )
//                       }
//                     </TouchableOpacity>
//                   </View>
//                   {
//                     !route?.params?.id && (
//                       <TouchableOpacity style={styles.edit} onPress={() => {
//                         navigation.navigate(strings.UPDATE_PRO)
//                       }}>

//                         <EditIcon />
//                       </TouchableOpacity>
//                     )
//                   }
//                 </View>
//                 <View style={[styles.nameConatiner]}>
//                   <AppText size={24} color={COLORS.white} family='PoppinsMedium' align='center'>{userdata ? userdata?.data?.full_name : userDetails?.full_name}</AppText>
//                   <View style={styles.terms}>
//                     <SilverMedal />
//                     <AppText size={16} color={COLORS.greyAD} family='PoppinsRegular' horizontal={5}
//                     >{'Rank'}</AppText>
//                     <AppText size={16} color={COLORS.greyD9} family='PoppinsBold'
//                     >{'2025'}</AppText>
//                   </View>
//                 </View>
//                 <View style={styles.row}>
//                   <TouchableOpacity onPress={() => navigation.navigate('FollowerList', {
//                     title: 'Following',
//                     id: userdata?.data?.user_id
//                   })} >
//                     <AppText size={24} color={COLORS.white} family='PoppinsMedium' align='center'>{userdata?.following_count}</AppText>
//                     <AppText size={14} color={COLORS.greyBBBB} family='PoppinsRegular'>Following</AppText>
//                   </TouchableOpacity>
//                   <TouchableOpacity onPress={() => navigation.navigate('FollowerList', {
//                     title: 'Followers',
//                     id: userdata?.data?.user_id
//                   })}>
//                     <AppText size={24} color={COLORS.white} family='PoppinsMedium' align='center'>{userdata?.follower_count}</AppText>
//                     <AppText size={14} color={COLORS.greyBBBB} family='PoppinsRegular'>Followers</AppText>
//                   </TouchableOpacity>
//                 </View>
//                 <View style={styles.totalContainer}>
//                   <View style={styles.totalrides}>
//                     <AppText size={15} color={COLORS.white} family='PoppinsMedium' >Total Rides</AppText>
//                     <AppText size={18} color={COLORS.greyC4C4} family='PoppinsRegular'>128</AppText>
//                   </View>
//                   <View style={styles.totalrides}>
//                     <AppText size={15} color={COLORS.white} family='PoppinsMedium' >Total Travel</AppText>
//                     <AppText size={18} color={COLORS.greyC4C4} family='PoppinsRegular'>123k kms</AppText>
//                   </View>
//                 </View>
//               </View>
//             )
//           }
//         </View>
//         <View style={{ marginTop: 70 }} />
//         <StackProfile navigation={navigation} headers={headers} data={userdata?.data} />
//       </View>
//       <Modal visible={modalVisible} animationType="slide" transparent={true}>
//         <View style={styles.modalContainer}>
//           <View style={styles.modalContent}>
//             <TouchableOpacity
//               onPress={() => {
//                 getCamera();
//               }}
//               style={styles.camera}>
//               <CamerasIcon />
//               <AppText
//                 size={16}
//                 color={COLORS.black}
//                 family="PoppinsMedium"
//                 horizontal={15}>
//                 Camera
//               </AppText>
//             </TouchableOpacity>
//             <TouchableOpacity
//               onPress={() => {
//                 setModalVisible(false);
//                 takePhotoFromLibray();
//               }}
//               style={styles.camera}>
//               <PhotosIcon />
//               <AppText
//                 size={16}
//                 color={COLORS.black}
//                 family="PoppinsMedium"
//                 horizontal={15}>
//                 Gallery
//               </AppText>
//             </TouchableOpacity>
//             <TouchableOpacity
//               onPress={() => setModalVisible(false)}
//               style={{ alignItems: 'flex-end' }}>
//               <AppText
//                 size={18}
//                 color={COLORS.fadeRrrorRed}
//                 family="PoppinsMedium">
//                 Cancel
//               </AppText>
//             </TouchableOpacity>
//           </View>
//         </View>
//       </Modal>
//     </ScrollView>
//   );
// };

// export default ProfileScreen;


import { View, ScrollView, TouchableOpacity, SafeAreaView, Modal, PermissionsAndroid, Image } from 'react-native';
import React, { useContext, useEffect, useState } from 'react';
import { styles } from './styles';
import FastImage from 'react-native-fast-image';
import { ArrowBAckIcon, CameraIcon, CamerasIcon, EditIcon, PhotosIcon, SilverMedal } from '../../assets/svgImg/SvgImg';
import AppText from '../../component/AppText/AppText';
import { COLORS } from '../../style';
import StackProfile from './StackProfile';
import { requestFollowUser, requestGetDetails, requestProfileImage } from '../../services/api_Services';
import { AuthContext } from '../../component/auth/AuthContext';
import ImagePicker from 'react-native-image-crop-picker';
import { strings } from '../../utils/strings';
import Skeleton from '../../component/Skeleton/Skeleton';
import emitter from '../../component/Emitter/emitter';
import Video from 'react-native-video';
import Animated from 'react-native-reanimated';
import { SharedElement } from 'react-navigation-shared-element';

type profileProps = {
  navigation: any,
  route: any
  loading: any
  setStatus: any
  status: any
  UserFollowApi: any
  modalVisible: any
  setModalVisible: any
  setPic: any
  pic: any
  userdata: any
  getCamera: any
  takePhotoFromLibray: any
  // status: any
  // status: any
}

const headers = [
  { id: 1, title: 'My Activities' },
  { id: 2, title: 'Club' },
  { id: 3, title: 'Group' }
];

const ProfileScreen = ({ navigation, route, loading, setStatus, status, UserFollowApi, modalVisible, setModalVisible, pic, setPic, userdata, getCamera, takePhotoFromLibray }: profileProps) => {
  const { userProfilePic, userDetails, userToken, authprofile }: any = useContext(AuthContext);
  const [cardData] = useState(new Array(1).fill(0));
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} bounces={false}>
      <View style={styles.container}>
        <View>
          {
            !loading ? (
              <>
                <View style={{ height: 200, width: '100%', flex: 1 }}>
                  <Video
                    source={require('../../assets/videos/routeVideo.mp4')} // Local MP4 file
                    style={{ height: '100%', width: '100%' }}
                    resizeMode="cover"
                    repeat
                    muted
                  >
                  </Video>
                  <View style={{ position: 'absolute', width: "100%" }}>
                    <SafeAreaView />
                    <View style={styles.arrow}>
                      <TouchableOpacity onPress={() => navigation.goBack()} style={{ flexDirection: 'row', alignItems: "center", paddingVertical: 10 }}>
                        <ArrowBAckIcon active={COLORS.white} />
                        <AppText size={20} color={COLORS.white} family='PoppinsBold' horizontal={25}>
                          {'Profile'}
                        </AppText>
                      </TouchableOpacity>
                      {
                        route?.params?.id && route.params.id !== userDetails?.id && (
                          <TouchableOpacity style={[styles.join]} onPress={() => {
                            setStatus(!status)
                            UserFollowApi()
                          }}>
                            <AppText size={14} color={COLORS.white} family='PoppinsSemiB'>
                              {status == true ? "Following" : "Follow"}
                            </AppText>
                          </TouchableOpacity>
                        )
                      }
                    </View>
                  </View>
                </View>

                {/* <View style={{ height: 260, width: '100%', position: 'absolute' }} /> */}

                <View style={styles.imageView}>
                  <View style={{ flexDirection: 'row', alignItems: 'flex-end', width: '80%' }}>
                    <View style={{ alignItems: 'center', width: '100%' }}>
                      <TouchableOpacity style={styles.profileConatiner}
                        onPress={() => {
                          !route?.params?.id && setModalVisible(true);
                        }}
                        onLongPress={() => {
                          if (userdata?.data?.profile_picture) {
                            navigation.push("ImageDetails", {
                              item: {
                                id: 1
                              }, url: userdata?.data?.profile_picture
                            })
                          }
                        }}>
                        <SharedElement id={`item.${1}.logo`}>
                          <Image
                            style={styles.image}
                            source={pic ?
                              { uri: pic } :
                              userdata ?
                                userdata?.data?.profile_picture ?
                                  { uri: userdata?.data?.profile_picture } :
                                  require('../../assets/img/profilepic.jpg') :
                                authprofile ?
                                  { uri: authprofile } :
                                  require('../../assets/img/profilepic.jpg')
                            }
                          />
                        </SharedElement>

                        {
                          !route?.params?.id && (
                            <TouchableOpacity style={styles.editContainer}
                              onPress={() => {
                                setModalVisible(true);
                              }}>
                              <CameraIcon />
                            </TouchableOpacity>
                          )
                        }
                      </TouchableOpacity>
                    </View>
                    {
                      !route?.params?.id && (
                        <TouchableOpacity style={styles.edit} onPress={() => {
                          navigation.navigate(strings.UPDATE_PRO)
                        }}>
                          <EditIcon />
                        </TouchableOpacity>
                      )
                    }
                  </View>
                  <View style={[styles.nameConatiner]}>
                    <AppText size={24} color={COLORS.white} family='PoppinsMedium' align='center'>{userdata ? userdata?.data?.full_name : userDetails?.full_name}</AppText>
                  </View>
              
                  <View style={styles.totalContainer}>
                    <TouchableOpacity style={styles.totalrides} onPress={() => navigation.push('FollowerList', {
                      title: 'Following',
                      id: userdata?.data?.user_id
                    })}>
                      <AppText size={16} color={COLORS.white} family='PoppinsMedium' >{userdata?.following_count}</AppText>
                      <AppText size={11} color={COLORS.greyBBBB} family='PoppinsRegular'>Following</AppText>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.totalrides} onPress={() => navigation.push('FollowerList', {
                      title: 'Followers',
                      id: userdata?.data?.user_id
                    })}>
                      <AppText size={16} color={COLORS.white} family='PoppinsMedium' >{userdata?.follower_count}</AppText>
                      <AppText size={11} color={COLORS.greyBBBB} family='PoppinsRegular'>Followers</AppText>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.totalrides}
                      onPress={() =>
                        navigation.push('TopRootsScreen', {
                          data: userdata?.data?.user_id,
                        })
                      }>
                      <AppText
                        size={16}
                        color={COLORS.white}
                        family="PoppinsMedium">
                        {userdata?.totalBikeRides}
                      </AppText>
                      <AppText
                        size={11}
                        color={COLORS.greyBBBB}
                        family="PoppinsRegular">
                        Total Rides
                      </AppText>
                    </TouchableOpacity>
                    <View style={styles.totalrides}>
                      <AppText size={16} color={COLORS.white} family='PoppinsMedium' >{userdata?.totalKM} kms</AppText>
                      <AppText size={11} color={COLORS.greyBBBB} family='PoppinsRegular'>Total Travels</AppText>
                    </View>
                  </View>
                </View>
                <View style={{ marginTop: 70 }} />
                {/* <StackProfile navigation={navigation} headers={headers} data={userdata?.data} /> */}
              </>
            ) : (
              <ScrollView style={{ flex: 1 }} keyboardShouldPersistTaps='always' keyboardDismissMode='on-drag'>
                {cardData.map((_, index) => (
                  <View style={{}}>
                    <Skeleton type="box" height={240} width={'100%'} />
                    <View style={{ marginTop: -50, alignItems: 'center' }}>
                      <Skeleton type="circle" height={120} width={120} borderRadius={100} />
                      <Skeleton type="box" height={20} width={'30%'} style={{ marginVertical: 20 }} />
                      <Skeleton type="box" height={20} width={'50%'} />
                    </View>
                  </View>
                ))}
              </ScrollView>
            )
          }
        </View>

      </View>
      <Modal visible={modalVisible} animationType="slide" transparent={true}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <TouchableOpacity
              onPress={() => {
                getCamera();
              }}
              style={styles.camera}>
              <CamerasIcon />
              <AppText
                size={16}
                color={COLORS.black}
                family="PoppinsMedium"
                horizontal={15}>
                Camera
              </AppText>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                setModalVisible(false);
                takePhotoFromLibray();
              }}
              style={styles.camera}>
              <PhotosIcon />
              <AppText
                size={16}
                color={COLORS.black}
                family="PoppinsMedium"
                horizontal={15}>
                Gallery
              </AppText>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setModalVisible(false)}
              style={{ alignItems: 'flex-end' }}>
              <AppText
                size={18}
                color={COLORS.fadeRrrorRed}
                family="PoppinsMedium">
                Cancel
              </AppText>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
};

export default ProfileScreen;