import { View, Text, TouchableOpacity } from 'react-native'
import React, { useEffect, useState } from 'react'
import { styles } from './styles'
import AppText from '../../component/AppText/AppText'
import { COLORS } from '../../style'
// import { getLinkPreview, getPreviewFromContent } from "link-preview-js";

const ShowMore = ({ description }: any) => {
  const [showMore, setShowMore] = useState(false);
  const [urlView, setUrlView] = useState(false);

  const text = description;

  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const urls = text?.match(urlRegex);

  if (urls) {
    urls.forEach((url: any) => console.log(url, "URLs found in the text"));
  } else {
    // console.log("No URLs found in the text.");
  }

  useEffect(() => {
    // getLinkPreview("https://www.youtube.com/watch?v=MejbOFk7H6c").then((data) =>
    //   console.debug(data)
    // );
  }, [])

  return (
    <View style={styles.postDesc}>
      <AppText size={14} numLines={showMore ? 0 : 3} dotMode='tail' family="PoppinsRegular" color={COLORS.whiteEB}>
        {description}
        {/* {item?.description.length < 40
        ? item?.description
        : `${getFirst200Words(item?.description)}...`} */}
      </AppText>
      {description.length > 70 ? (
        <TouchableOpacity onPress={() => {
          setShowMore(!showMore)
        }}>

          <AppText
            size={14}
            family="PoppinsRegular"
            color={COLORS.lightyellow}>
            {showMore ? "Read less" : "Read more"}
          </AppText>
        </TouchableOpacity>)
        : (
          null
        )
      }

    </View>
  )
}

export default ShowMore