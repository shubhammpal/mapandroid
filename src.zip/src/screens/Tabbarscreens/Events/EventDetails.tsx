import { View, Text, ImageBackground, TouchableOpacity, ActivityIndicator, Modal, Image, SafeAreaView } from 'react-native';
import React, { useCallback, useContext, useEffect, useState } from 'react';
import { styles } from './styles';
import AppText from '../../../component/AppText/AppText';
import { COLORS, ms } from '../../../style';
import {
  ArrowBAckIcon,
  BikeCCIcon,
  CalendarIcon,
  CommunityIcon,
  CrossRedIcon,
  DestinationICon,
  EditIcon,
  MaxRidersIcon,
  RideDurationIcon,
  RidesrouteIcon,
  RidingskillsIcon,
  StartlocationICon,
  StarttimeIcon,
  ThreeDotStraighIcon,
  TotalkmsIcon,
} from '../../../assets/svgImg/SvgImg';
import SubmitButton from '../../../component/ButtonCotainer/SubmitButton';
import { formatDate, formatTime } from '../../../style/typography';
import { strings } from '../../../utils/strings';
import { AuthContext } from '../../../component/auth/AuthContext';
import { fonts } from '../../../utils/misc';
import { getEventRideData } from '../../../services/api_Services';

const EventDetails = ({ navigation, data }: any) => {
  const { userDetails, userToken }: any = useContext(AuthContext);
  const [saveModal, setSaveModal] = React.useState(false);
  const [checked, setChecked] = useState(false);
  const [rideDetails, setRideDetails] = useState<any[]>([]);
  const [checkedUsers, setCheckedUsers] = useState<any[]>([]);
  useEffect(() => {
    getEventRideDetails()
  }, [data])

  const toggleChecked = (userId: any) => {
    let updatedUsers = [...checkedUsers];
    if (updatedUsers.includes(userId)) {
      updatedUsers = updatedUsers.filter(id => id != userId);
    } else {
      updatedUsers.push(userId);
    }
    setCheckedUsers(updatedUsers);
    handleNext()
  };
  const getEventRideDetails = async () => {
    console.log("====")
    if (data) {
      const apiData = { token: userToken, eventId: data?._id };
      
      try {
        await getEventRideData(apiData).then(async (res: any) => {
          console.log(res)
          if (res.length > 0) {
            setRideDetails(res)
          }
        });
      } catch (error) {
        console.log('PostList response: ', error);
      }
    }
  };
  const handleNext = () => {
    // Perform API call for each checked user
    checkedUsers.forEach(userId => {
      const action = checkedUsers.includes(userId) ? 'add' : 'remove';
      console.log(userId, 'userIduserId')
      fetch('http://3.111.234.55:6004/group/events/mark-attendance', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Cookie': 'connect.sid=s%3AD5Ev5KQwLGU4fMCZZ9Li9f8P8KffqywP.1h7rbwvgTYonk6uKEPlTFnZgFSGNhXMFicuYfb0dUow; connect.sid=s%3AD9SUaFCgc0q07QVRJmpqPLeC7t2U74ED.%2BYav4PG3J1zWlNlKsVRKYpulJkaAddVs9zgTWQlSeME',
        },
        body: JSON.stringify({
          eventId: data?._id,
          userId: userId,
          action: action,
        }),
      })
        .then(response => response.json())
        .then(data => {
          // Handle API response
          console.log(data, 'ss');
        })
        .catch(error => {
          // Handle error
          console.error('Error:', error);
        });
    });

    // Close the modal after processing
    // setSaveModal(false);
  };
  return (
    <View>
      {
        !data ? (
          <View style={{ marginTop: ms(8) }}>
            <ActivityIndicator size={50} color={COLORS.white} />
          </View>
        ) : (
          <>
            <ImageBackground
              source={ data?.files?.length != 0 ? { uri: data?.files[0]?.url } : require('../../../assets/img/noimage.png')}
             
              style={{
                height: 250,
              }}>
              {/* <View style={styles.photoContainer}>
                <View style={[styles.row, { paddingHorizontal: 20 }]}>
                  <View style={[styles.status]}>
                    <AppText
                      size={14}
                      color={COLORS.whiteF7F7}
                      family="PoppinsMedium">
                      {'Only For Royal Enfield'}
                    </AppText>
                  </View>
                  <View style={styles.price}>
                    <AppText
                      size={14}
                      color={COLORS.whiteF7F7}
                      family="PoppinsMedium">
                      {'₹2500'}
                    </AppText>
                  </View>
                </View>
              </View> */}
              {
                data?.owner_id == userDetails?.id && (
                  <View style={styles.editContainer}>
                    <TouchableOpacity style={[styles.price, { paddingVertical: 10 }]} onPress={() => {
                      if (data?.groupId) {
                        navigation.navigate(strings.CREATE_EVENT, {
                          id: data?.groupId,
                          data: 'data',
                          update: 'update',
                          rideId: data?._id
                        })
                      } else {
                        navigation.navigate(strings.CREATE_EVENT, {
                          data: 'data',
                          clubId: data?.clubId,
                          update: 'update',
                          rideId: data?._id
                        })
                      }

                    }}>
                      <EditIcon />
                      <AppText
                        size={14}
                        horizontal={10}
                        color={COLORS.whiteF7F7}
                        family="PoppinsMedium">
                        {'Edit Ride'}
                      </AppText>
                    </TouchableOpacity>
                  </View>
                )
              }
            </ImageBackground>
            <View style={{ marginHorizontal: 15, marginVertical: 15 }}>
              {(data?.startingPoint && data?.destination) ?
                <AppText size={24} color={COLORS.white} family="PoppinsMedium">
                  {`${data?.startingPoint} to ${data?.destination}`}
                </AppText>
                : null}

              <View style={{ marginTop: 5 }} />
              <AppText size={14} color={COLORS.white} family="PoppinsLight">
                {data?.description}
              </AppText>
              <View style={[styles.row2, {}]}>
                <View style={styles.rowData}>
                  <View style={styles.iconContainer}>
                    <CalendarIcon active={'#7AA2CE'} />
                  </View>
                  <View style={{ marginHorizontal: 20, width: '65%' }}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      Start Date
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {(data?.startTime)}
                    </AppText>
                  </View>
                </View>
                <View style={styles.rowData}>
                  <View style={styles.iconContainer}>
                    <CalendarIcon active={'#7AA2CE'} />
                  </View>
                  <View style={{ marginHorizontal: 20, width: '65%' }}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      End Date
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {(data?.startTime)}
                    </AppText>
                  </View>
                </View>

              </View>
              <View style={[styles.row2, {}]}>
                <View style={styles.rowData}>
                  <View style={styles.iconContainer}>
                    <RideDurationIcon />
                  </View>
                  <View style={{ marginHorizontal: 20 }}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      Ride Duration
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {data?.rideDuration}
                    </AppText>
                  </View>
                </View>
                <View style={styles.rowData}>
                  <View style={styles.iconContainer}>
                    <TotalkmsIcon />
                  </View>
                  <View style={{ marginHorizontal: 20 }}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      Total KM
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {data?.totalKms} Km
                    </AppText>
                  </View>
                </View>
              </View>
              {
                data?.clubId == "undefined" || data?.clubId == null ? null : (
                  <>
                    <View style={[styles.row2, {}]}>
                      <View style={styles.rowData}>
                        <View style={styles.iconContainer}>
                          <MaxRidersIcon />
                        </View>
                        <View style={{ marginHorizontal: 20 }}>
                          <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                            Max Riders
                          </AppText>
                          <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                            {data?.maxRiders}
                          </AppText>
                        </View>
                      </View>
                      <View style={styles.rowData}>
                        <View style={styles.iconContainer}>
                          <RidingskillsIcon />
                        </View>
                        <View style={{ marginHorizontal: 20 }}>
                          <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                            Riding Skills
                          </AppText>
                          <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                            {data?.ridingSkills}
                          </AppText>
                        </View>
                      </View>
                    </View>
                    <View style={[styles.row2, {}]}>
                      <View style={styles.rowData}>
                        <View style={styles.iconContainer}>
                          <BikeCCIcon />
                        </View>
                        <View style={{ marginHorizontal: 20 }}>
                          <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                            Bike CC
                          </AppText>
                          <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                            {data?.bikeCC}
                          </AppText>
                        </View>
                      </View>
                      <View style={styles.rowData}>
                        <View style={styles.iconContainer}>
                          <StarttimeIcon />
                        </View>
                        <View style={{ marginHorizontal: 20, width: '78%' }}>
                          <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                            Start Time
                          </AppText>
                          <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                            {(data?.reportingTime)}
                          </AppText>
                        </View>
                      </View>
                      {/* <View style={styles.rowData}>
                        <View style={styles.iconContainer}>
                          <CommunityIcon active={'#7AA2CE'} />
                        </View>
                        <View style={{ marginHorizontal: 20 }}>
                          <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                            Rider Group
                          </AppText>
                          <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                            {data?.rideGroup}
                          </AppText>
                        </View>
                      </View> */}
                    </View>
                  </>
                )
              }
              <View style={{ marginVertical: 15 }}>
                <AppText size={20} color={COLORS.white} family="PoppinsMedium">
                  Ride Map
                </AppText>
                <View style={styles.row2}>
                  <View style={styles.iconContainer}>
                    <StartlocationICon />
                  </View>
                  <View style={{ marginHorizontal: 15, width: '88%' }}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      Start
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {data?.fromLocation?.name}
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {data?.startPointMapLink}
                    </AppText>
                  </View>
                </View>
                <View style={styles.row2}>
                  <View style={styles.iconContainer}>
                    <DestinationICon />
                  </View>
                  <View style={{ marginHorizontal: 15, width: '88%' }}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      Destination
                    </AppText>
                    <AppText size={14} color={COLORS.semiAAA} family="PoppinsRegular">
                      {data?.toLocation?.name}
                    </AppText>

                  </View>
                </View>
                <View style={[styles.row2, { alignItems: "center" }]}>
                  <View style={styles.iconContainer}>
                    <RidesrouteIcon />
                  </View>
                  <TouchableOpacity style={{ marginHorizontal: 15, width: '88%' }} onPress={() => navigation.navigate('ViewRideMap', { data: data })}>
                    <AppText size={15} color={COLORS.white} family="PoppinsMedium">
                      View Full Map
                    </AppText>
                  </TouchableOpacity>
                </View>
              </View>
              {/* <View style={styles.button}>
                <SubmitButton
                  title={'Mark attandence'}
                  pressing={() => setSaveModal(true)}
                  widthOf={'98%'}
                  height={46}
                />
              </View> */}
              {
                data?.owner_id == userDetails?.id ? (
                  <View style={styles.button}>
                    <SubmitButton
                      title={'Start Ride'}
                      pressing={() => {
                        // if()
                        // setSaveModal(true)
                        navigation.navigate('Attendance', { data: data })
                      }}
                      // pressing={() => setSaveModal(true)}
                      widthOf={'98%'}
                      height={46}
                    />
                  </View>
                ) : (
                  <View style={styles.button}>
                    <SubmitButton
                      title={rideDetails.length == 0 ? "Ride will be start" : 'View map'}
                      pressing={() => {
                        if (rideDetails.length > 0) {
                          navigation.navigate(strings.USER_MAP, data)
                        } else {

                        }
                      }}
                      widthOf={'98%'}
                      height={46}
                    />
                  </View>
                )
              }
            </View>

          </>
        )
      }
      {/* <Modal
        transparent
        visible={saveModal}
        animationType="slide">
        <View style={styles.savecontainerModal}>
          <SafeAreaView />
          <View style={[styles.repeatmodalView, { flex: 1, alignSelf: 'center', }]}>
            <View style={{
              flex: 1, marginTop: 15, marginHorizontal: 15,
            }}>
              <View style={styles.topHeaderSafe}>
                <TouchableOpacity style={styles.closeButton} onPress={() => setSaveModal(false)}>
                  <ArrowBAckIcon />
                </TouchableOpacity>
                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', }}>
                  <AppText size={20} color={COLORS.white} family='PoppinsBold' align='center'>
                    Attendance
                  </AppText>
                </View>
              </View>
              {
                data && (
                  data?.registeredUsers?.map((item, index) => (
                    <TouchableOpacity key={item?.id} style={{
                      flexDirection: 'row', alignItems: 'center',
                      marginTop: 20, justifyContent: 'space-between'
                    }} onPress={() => toggleChecked(item?.id)}>
                      <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                        <Image
                          source={
                            item?.profile_picture == null
                              ? require('../../../assets/img/profilepic.jpg')
                              : { uri: item?.profile_picture }
                          }
                          style={{ width: 50, height: 50, borderRadius: 25 }}
                        />
                        <AppText
                          size={16}
                          color={COLORS.white}
                          family={fonts.QuicksandSemi}
                          horizontal={25}>
                          {item?.full_name}
                        </AppText>

                      </View>
                      <TouchableOpacity style={{ marginRight: 20, justifyContent: 'center' }} onPress={() => toggleChecked(item?.id)}>
                        <View style={styles.checkBox}>

                          <Image
                            style={styles.check}
                            source={checkedUsers.includes(item?.id) ? require('../../../assets/img/checkmark.png') : null}
                          />

                        </View>
                      </TouchableOpacity>
                      
                    </TouchableOpacity>
                  ))
                )
              }

            </View>
            <View style={{ marginVertical: 50, marginHorizontal: 15 }}>
              <SubmitButton
                title={'Next'}
                pressing={() => {
                  setSaveModal(false)
                  navigation.navigate(strings.USER_MAP)
                }}
                widthOf={'100%'}
                height={46}
              />
            </View>
          </View>
        </View>
      </Modal> */}
    </View>
  );
};

export default EventDetails;
