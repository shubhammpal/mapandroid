import { View, Text } from 'react-native'
import React from 'react'

const BlockScreen = () => {
  return (
    <View>
      <Text>BlockScreen</Text>
    </View>
  )
}

export default BlockScreen