import { View, Text } from 'react-native'
import React from 'react'

const TabRoutes = () => {
  return (
    <View>
      <Text>TabRoutes</Text>
    </View>
  )
}

export default TabRoutes