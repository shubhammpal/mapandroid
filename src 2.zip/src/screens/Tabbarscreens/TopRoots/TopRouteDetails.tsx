import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import {
  BikeCCIcon,
  RestaurantIcon,
  TimeIcon,
} from '../../../assets/svgImg/SvgImg';
import AppText from '../../../component/AppText/AppText';
import SubmitButton from '../../../component/ButtonCotainer/SubmitButton';
import SimpleHeader from '../../../component/header/Header';
import {COLORS} from '../../../style';

interface RouteDetailsProps {
  navigation: any;
}

const TopRouteDetails: React.FC<RouteDetailsProps> = ({navigation}) => {
  return (
    <SafeAreaView style={styles.container}>
      <SimpleHeader label="Top Routes" navigation={navigation} />
      <ScrollView contentContainerStyle={styles.container}>
        <View>
          {/* <Image
            source={require('../assets/greengarden.jpg')}
            style={styles.image}
          /> */}
        </View>
        <Text style={styles.imageCaption}>
          “Remember to ride with safety gears”
        </Text>
        <View style={{paddingHorizontal: 16}}>
          <View style={styles.routeInfoContainer}>
            <AppText size={15} family="PoppinsSemiB" color={COLORS.white}>
              About the route
            </AppText>
            <AppText size={14} family={'PoppinsBold'} color="white">
              Riding from Pune to Malshej Ghat by bike is an enchanting
              experience, filled with scenic beauty and thrilling curves. The
              journey offers lush green landscapes, especially vibrant during
              the monsoon season. As you ascend, the cool mountain breeze and
              occasional waterfalls add to the charm. The roads are
              well-maintained, making for a smooth and enjoyable ride. The
              breathtaking views from the top of the Ghat are the perfect reward
              for the adventure.
            </AppText>
            <View style={{marginVertical: 15, gap: 10}}>
              <View style={{alignItems: 'center', flexDirection: 'row'}}>
                <AppText
                  size={13}
                  horizontal={5}
                  family="PoppinsSemiB"
                  color={COLORS.white}>
                  <BikeCCIcon />
                  verified mechanic shops throughout the route.
                </AppText>
                <TouchableOpacity>
                  <AppText
                    size={13}
                    horizontal={5}
                    family="PoppinsSemiB"
                    color={COLORS.blue}>
                    Show
                  </AppText>
                </TouchableOpacity>
              </View>
              <AppText
                size={13}
                horizontal={5}
                family="PoppinsSemiB"
                color={COLORS.white}>
                <TimeIcon />3 H 25 M
              </AppText>
              <AppText
                size={13}
                horizontal={5}
                family="PoppinsSemiB"
                color={COLORS.white}>
                <RestaurantIcon />
                Bike Friendly Restaurants (All amenities)
              </AppText>
              <AppText
                size={13}
                horizontal={5}
                family="PoppinsSemiB"
                color={COLORS.white}>
                <BikeCCIcon />
                Emergency Hospitals and ER
              </AppText>
            </View>
          </View>
          <Text style={styles.suitedRouteTitle}>Choose best suited route</Text>
          <View style={styles.routeOptionsContainer}>
            {[
              'Short',
              'Fastest',
              'Thrilling',
              'Super Thrilling',
              'Alternative',
              'Alternative',
            ].map((option, index) => (
              <TouchableOpacity key={index} style={styles.routeOptionButton}>
                {/* <Image
                  style={{height: 18, width: 18}}
                  source={require('../assets/short.png')}
                /> */}
                <AppText horizontal={10} color="#FFF" size={16}>
                  {option}
                </AppText>
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.submitButton}>
            <SubmitButton title="Start" widthOf={'40%'} pressing={() => {}} />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: COLORS.black1B1D,
  },
  image: {
    width: '100%',
    height: 200,
  },
  imageCaption: {
    color: '#FFF',
    textAlign: 'center',
    marginVertical: 8,
    marginBottom: 15,
  },
  routeInfoContainer: {
    borderRadius: 10,
    gap: 10,
  },
  routeTitle: {
    color: '#FFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },

  aboutText: {
    color: '#FFF',
    fontSize: 16,
    marginBottom: 8,
  },
  routeDetail: {
    color: '#FFF',
    fontSize: 16,
    marginBottom: 4,
  },
  suitedRouteTitle: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 16,
  },
  routeOptionsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginRight: 10,
    marginBottom: 10,
  },
  routeOptionButton: {
    backgroundColor: '#444',
    borderRadius: 10,
    padding: 12,
    marginVertical: 4,
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 10,
  },
  startButton: {
    backgroundColor: '#1E90FF',
    borderRadius: 10,
    padding: 16,
    alignItems: 'center',
    marginVertical: 16,
  },
  startButtonText: {
    color: '#FFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  submitButton: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    width: '100%',
  },
});

export default TopRouteDetails;
