import React from 'react';
import { View, SafeAreaView, StyleSheet, FlatList } from 'react-native';
import SimpleHeader from '../../../component/header/Header';
import { black } from '../../../style/Colors';
import TopRoutesCard from './TopRouteCard';
import { strings } from '../../../utils/strings';
import { ms } from '../../../style';

const data = [
  {
    id: 1,
    place: 'Pune - Malshej Ghat',
    time: '3 H 36 M',
    distance: '121 K.M',
    image:require('../../../assets/img/natureImage1.png')
  },
  {
    id: 2,
    place: 'Pune - Mahabaleshwar',
    time: '3 H 24 M',
    distance: '120 K.M',
    image:require('../../../assets/img/natureImage2.png')
  },
  {
    id: 3,
    place: 'Pune - Matheran',
    time: '3 H 45 M',
    distance: '124 K.M',
    image:require('../../../assets/img/natureImage3.png')
  },
  {
    id: 4,
    place: 'Pune - Alibaug',
    time: '4 H 00 M',
    distance: '140 K.M',
    image:require('../../../assets/img/natureImage4.png')
  },
  
];

const TopRoutes = ({ navigation }: any) => {

  const renderItem = ({ item, index }: { item: any; index: any }) => {
    return (
      <TopRoutesCard
        onpress={() => { navigation.navigate(strings.TopRoute_DETAIL) }}
        place={item?.image}
        placeName={item?.place}
        time={item?.time}
        distance={item?.distance}
      />
    );
  };
  return (
    <SafeAreaView style={styles.container}>
      <View>
        {/* <SimpleHeader label="Top Routes" navigation={navigation} /> */}

        <FlatList
          data={data}
          renderItem={renderItem}
          bounces={false}
          style={{paddingBottom:ms(10)}}
          contentContainerStyle={{ flexGrow: 1, paddingBottom: 30, paddingTop: 16,width:'90%',alignSelf:'center' }}
        />
        {/* <TopRoutesCard
          onpress={() => { navigation.navigate(strings.TopRoute_DETAIL) }}
          place={'Pune - Matheran'}
          time={'3 H 45 M'}
          distance={'124 K.M'}
        />
        <TopRoutesCard
          onpress={() => { }}
          place={'Pune - Matheran'}
          time={'3 H 45 M'}
          distance={'124 K.M'}
        /> */}
      </View>
    </SafeAreaView>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: black,
  },

});

export default TopRoutes;
