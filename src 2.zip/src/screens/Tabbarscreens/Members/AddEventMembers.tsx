// import React, { useCallback, useContext, useEffect, useState } from 'react';
// import {
//   ActivityIndicator,
//   Dimensions,
//   Image,
//   ImageBackground,
//   Linking,
//   PermissionsAndroid,
//   SafeAreaView,
//   ScrollView,
//   StyleSheet,
//   TextInput,
//   TouchableOpacity,
//   View,
// } from 'react-native';
// import { AuthContext } from '../../../component/auth/AuthContext';
// import emitter from '../../../component/Emitter/emitter';
// import { styles } from './styles';
// import { AddIcon, ArrowBAckIcon } from '../../../assets/svgImg/SvgImg';
// import AppText from '../../../component/AppText/AppText';
// import { COLORS, ms } from '../../../style';
// import { fonts } from '../../../utils/misc';
// import { requestEventUserRegister, requestMemberListbyClub, requestMemberListbyGroup } from '../../../services/api_Services';
// import { useFocusEffect } from '@react-navigation/native';
// import { strings } from '../../../utils/strings';
// import Contacts from 'react-native-contacts';
// import FastImage from 'react-native-fast-image';
// import SendSMS from 'react-native-sms'
// import dynamicLinks from '@react-native-firebase/dynamic-links';


// const AddEventMembersScreen = ({ navigation, route }: any) => {
//   const [searchingText, setSearchingText] = useState<any>('');
//   const { userToken, userDetails }: any = useContext(AuthContext);
//   const [getuserData, setGetuserData] = useState<any>();
//   const [selectedUsers, setSelectedUsers] = useState<any>([]);
//   const [selectedUsersContact, setSelectedUsersContact] = useState<any>([]);
//   const [loader, setLoader] = useState<boolean>(false);
//   const [contactData, setContactData] = useState<any>();

//   const contactList = () => {
//     Contacts.getAll()
//       .then((contacts) => {
//         // work with contacts
//         setContactData(contacts);
//       })
//       .catch((e) => {
//         console.log(e);
//       });
//   }
//   useFocusEffect(
//     useCallback(() => {
//       console.log(route?.params?.data?.clubId)
//       if (route?.params?.data?.clubId) {
//         getClubMemberListData(route?.params?.data?.clubId)
//       }
//       GetMemebertlistData();
//       contactList()
//     }, []),
//   );

//   const getClubMemberListData = async (id: any) => {

//     const apiData = { clubId: id, token: userToken, search: '' };
//     try {
//       const res = await requestMemberListbyClub(apiData);
//       console.log(res, 'ss')
//       if (res?.status == true) {
//         setGetuserData(res?.data);
//       }
//     } catch (error) {
//       console.log('Club member list response: ', error);
//     }
//   };
//   const GetMemebertlistData = async () => {
//     const apiData = { group_id: route?.params?.data?.groupId, token: userToken };
//     try {
//       await requestMemberListbyGroup(apiData).then(async (res: any) => {
//         if (res?.status == true) {
//           setGetuserData(res?.payload);
//         }
//       });
//     } catch (error) {
//       console.log('Member list response: ', error);
//     }
//   };

//   const toggleSelectUser = (userId: any) => {
//     setSelectedUsers((prevSelected) => {
//       if (prevSelected.includes(userId)) {
//         return prevSelected.filter((id: any) => id !== userId);
//       } else {
//         return [...prevSelected, userId];
//       }
//     });
//   };
//   const toggleSelectUserContact = (phoneNumber: string) => {
//     setSelectedUsersContact((prevSelected) => {
//       if (prevSelected.includes(phoneNumber)) {
//         return prevSelected.filter((number: any) => number !== phoneNumber);
//       } else {
//         return [...prevSelected, phoneNumber];
//       }
//     });
//   };
//   // https://mytraclub.page.link/GMQ7
//   const EventUserRegister = async () => {
//     const userIds = selectedUsers.map(userId => (userId));
//     const apiData = { id: route?.params?.data?._id, token: userToken, userId: userIds };
//     if(selectedUsersContact.length > 0){
//       sendBulkMessage()
//     }
//     try {
//       await requestEventUserRegister(apiData)
//         .then(async (res: any) => {
//           navigation.goBack()
//         })
//     } catch (error) {
//       console.log("Event user register response: ", error);
//     }
//   }

//   const sendBulkMessage = async () => {
//     const getLink : any = await generateLink()
//     SendSMS.send({
//       body: `Hello, Join my club! \n${getLink}`,
//       recipients: selectedUsersContact,
//       successTypes: ['sent', 'queued'],
//       allowAndroidSendWithoutReadPermission: true
//     }, (completed, cancelled, error) => {

//       console.log('SMS Callback: completed: ' + completed + ' cancelled: ' + cancelled + 'error: ' + error);

//     });
//     // const defaultMessage = "Hello! Join my group.";
//     // console.log(selectedUsersContact)
//     // const phoneNumbers = selectedUsersContact.join(',');
//     // console.log(phoneNumbers)
//     // // return 
//     // const url = `sms:${phoneNumbers}?body=${encodeURIComponent(defaultMessage)}`;
//     // console.log(url)
//     // // return
//     // Linking.openURL(url);
//   };

//   const generateLink = async () => {
//     try {
//         const link = await dynamicLinks().buildShortLink({
//             link: `https://mytraclub.page.link/GMQ7?rideMemberAdd=${route?.params?.data?.clubId}`,
//             domainUriPrefix: 'https://mytraclub.page.link',
//             android: {
//                 packageName: 'com.thebikerscompany',
//             },
//             ios: {
//                 appStoreId: '6526488238',
//                 bundleId: 'com.mytra',
//             },
//         }, dynamicLinks.ShortLinkType.DEFAULT)
//         console.log('link:', link)
//         return link
//     } catch (error) {
//         console.log('Generating Link Error:', error)
//     }
// }
//   return (
//     <View style={{ flex: 1, backgroundColor: COLORS.black }}>
//       <ScrollView style={styles.addcontainer} bounces={false}>
//         <SafeAreaView />
//         <View style={styles.addcontainer}>
//           <View style={{ marginHorizontal: ms(2), marginVertical: ms(4) }}>
//             <View
//               style={{
//                 flexDirection: 'row',
//                 alignItems: 'center',
//                 justifyContent: 'space-between',
//               }}>
//               <View style={{ flexDirection: 'row', alignItems: 'center' }}>
//                 <TouchableOpacity onPress={() => navigation.goBack()}>
//                   <ArrowBAckIcon />
//                 </TouchableOpacity>
//                 <AppText
//                   size={20}
//                   color={COLORS.white}
//                   family="PoppinsSemiB"
//                   horizontal={20}>
//                   Add Member
//                 </AppText>
//               </View>
//               <TouchableOpacity
//                 style={[styles.addButton]}
//                 onPress={() => EventUserRegister()}>

//                 <AppText
//                   size={16}
//                   color={COLORS.white}
//                   align="center"
//                   horizontal={3}
//                   family={fonts.QuicksandBold}>
//                   {'Done'}
//                 </AppText>
//               </TouchableOpacity>
//             </View>
//             <View style={{ flexDirection: 'row', marginVertical: 20 }}>
//               <View style={[styles.SearchBox]}>
//                 <View style={styles.inputBox}>
//                   <TextInput
//                     value={searchingText}
//                     style={styles.input2}
//                     placeholderTextColor={COLORS.grey92}
//                     placeholder="Search for people"
//                     onChangeText={(text) => setSearchingText(text)}
//                     keyboardType="default"
//                   />
//                 </View>
//               </View>
//             </View>

//             <View style={{ marginVertical: 10 }}>
//               {loader ? (
//                 <View style={{ marginTop: ms(5) }}>
//                   <ActivityIndicator size={50} color={COLORS.white} />
//                 </View>
//               ) : (
//                 getuserData?.filter(
//                   (item) =>
//                     !route?.params?.data?.registeredUsers.some(
//                       (user) => user.id == item.user_id,
//                     ),
//                 )?.map((item, i) => {
//                   return (
//                     <TouchableOpacity key={item?.user_id} style={styles.inviteContainer} onPress={() => toggleSelectUser(item?.user_id)}>
//                       <View style={{ flexDirection: 'row', alignItems: 'center' }}>
//                         <Image
//                           source={
//                             item?.profile_picture == null
//                               ? require('../../../assets/img/profilepic.jpg')
//                               : { uri: item?.profile_picture }
//                           }
//                           style={styles.item}
//                         />
//                         <AppText
//                           size={16}
//                           color={COLORS.whiteFBFB}
//                           family={fonts.QuicksandSemi}
//                           horizontal={15}>
//                           {item?.full_name}
//                         </AppText>
//                       </View>
//                       <TouchableOpacity
//                         onPress={() => toggleSelectUser(item?.user_id)}
//                         style={[
//                           styles.inviteButton,
//                           {
//                             backgroundColor: selectedUsers.includes(item?.user_id)
//                               ? COLORS.red
//                               : COLORS.blue,
//                           },
//                         ]}>
//                         <AppText
//                           size={16}
//                           color={COLORS.white}
//                           family={fonts.QuicksandBold}>
//                           {selectedUsers.includes(item.user_id) ? 'Cancel' : 'Invite'}
//                         </AppText>
//                       </TouchableOpacity>
//                     </TouchableOpacity>
//                   )
//                 })
//               )}
//             </View>
//             <View style={{ marginVertical: 5 }}>
//               <AppText size={15} color='white' family='PoppinsMedium'>Invite from contacts:</AppText>
//               <View style={{ marginVertical: 5 }} />
//               {
//                 contactData && (
//                   <>
//                     {
//                       contactData.map((item: any, index: number) => {
//                         if (index == 0) {

//                         }
//                         return (
//                           <TouchableOpacity key={item?.phoneNumbers[0]?.number + item?.givenName} style={styles.inviteContainer}>
//                             <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, paddingRight: 50 }}>

//                               <FastImage
//                                 source={
//                                   item?.thumbnailPath
//                                     ? { uri: item?.thumbnailPath }
//                                     : require('../../../assets/img/profilepic.jpg')
//                                 }
//                                 style={styles.item}
//                               />
//                               <AppText
//                                 size={16}
//                                 color={COLORS.whiteFBFB}
//                                 family={fonts.QuicksandSemi}
//                                 horizontal={15} numLines={1} dotMode='tail'>
//                                 {item?.givenName} {item?.familyName}
//                               </AppText>
//                             </View>
//                             <TouchableOpacity
//                               onPress={() => toggleSelectUserContact(item?.phoneNumbers[0]?.number)}
//                               // onPress={() => toggleSelectUser(item?.user_id)}
//                               style={[
//                                 styles.inviteButton,
//                                 {
//                                   backgroundColor: selectedUsersContact.includes(item?.phoneNumbers[0]?.number)
//                                     ? COLORS.red
//                                     : COLORS.blue,
//                                 },
//                               ]}>
//                               <AppText
//                                 size={16}
//                                 color={COLORS.white}
//                                 family={fonts.QuicksandBold}>
//                                 {selectedUsersContact.includes(item?.phoneNumbers[0]?.number) ? 'Cancel' : 'Invite'}
//                               </AppText>
//                             </TouchableOpacity>
//                           </TouchableOpacity>
//                         )
//                       })
//                     }
//                   </>
//                 )
//               }


//             </View>
//           </View>
//         </View>
//       </ScrollView>
//     </View>
//   );
// };
// export default AddEventMembersScreen;
import React, { useCallback, useContext, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  PermissionsAndroid,
  SafeAreaView,
  ScrollView,
  Share,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { AuthContext } from '../../../component/auth/AuthContext';
import { styles } from './styles';
import { ArrowBAckIcon, LinkIcon } from '../../../assets/svgImg/SvgImg';
import AppText from '../../../component/AppText/AppText';
import { COLORS, ms } from '../../../style';
import { fonts } from '../../../utils/misc';
import { requestEventUserRegister, requestGetTagUserList, requestGetUserList, requestJoinClubAdd, requestMemberListbyClub, requestMemberListbyGroup } from '../../../services/api_Services';
import { useFocusEffect } from '@react-navigation/native';
import Contacts from 'react-native-contacts';
import FastImage from 'react-native-fast-image';
import SendSMS from 'react-native-sms';
import dynamicLinks from '@react-native-firebase/dynamic-links';
import emitter from '../../../component/Emitter/emitter';

const AddEventMembersScreen = ({ navigation, route }: any) => {
  const [searchingText, setSearchingText] = useState<string>('');
  const { userToken, userDetails }: any = useContext(AuthContext);
  const [getuserData, setGetuserData] = useState<any[]>([]);
  const [filteredUserData, setFilteredUserData] = useState<any[]>([]);
  const [selectedUsers, setSelectedUsers] = useState<any[]>([]);
  const [selectedUsersContact, setSelectedUsersContact] = useState<any[]>([]);
  const [loader, setLoader] = useState<boolean>(false);
  const [contactData, setContactData] = useState<any[]>([]);
  const [filteredContactData, setFilteredContactData] = useState<any[]>([]);
  const [searchData, setSearchData] = useState<any[]>([]);
  const [selectedGlobalUser, setSelectedGlobalUser] = useState<any[]>([]);
  const getCamera = async () => {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.READ_CONTACTS,
        {
          title: 'Access contacts',
          message: 'Can we access your contacts?',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      console.log('Android camera permission result:', granted);
  
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        contactList();
      } else {
        console.log('Android camera permission denied');
      }
    } catch (error) {
      console.error('Error requesting Android camera permission:', error);
    }
  };
  const contactList = () => {
    Contacts.getAll()
      .then((contacts) => {
        setContactData(contacts);
        setFilteredContactData(contacts);
      })
      .catch((e) => {
        console.log(e);
      });
  };

  useFocusEffect(
    useCallback(() => {
      if (route?.params?.data?.clubId) {
        getClubMemberListData(route?.params?.data?.clubId);
      } else {
        getClubMemberListData();
        getCamera();
      }
    }, [])
  );

  const getClubMemberListData = async (id?: any) => {
    // try {console.log(route?.params?.data, 'ooooo')
    //   await requestGetUserList(apiData).then(async (res: any) => {
    // const apiData = { clubId: id, token: userToken, search: '' };
    // try {
    //   const res = await requestMemberListbyClub(apiData);
    // const apiData = { clubId: id, token: userToken, search: '' };
    try {


      let apiData
      if (id) {
        apiData = { clubId: id, token: userToken, search: '' };
        const res = await requestMemberListbyClub(apiData);
        console.log(res, 'ppdpdpdpdpdpd')
        if (res?.status == true) {
          setGetuserData(res?.data || []);
          setFilteredUserData(res?.data || []);
        }
      } else {
        apiData = { token: userToken, user_id: userDetails?.id };
        const res = await requestGetUserList(apiData);

        if (res?.status == true) {
          setGetuserData(res?.payload || []);
          setFilteredUserData(res?.payload || []);
        }
      }

    } catch (error) {
      console.log('Club member list response: ', error);
    }
  };

  const GetMemebertlistData = async () => {
    const apiData = { group_id: route?.params?.data?.groupId, token: userToken };
    try {
      const res = await requestMemberListbyGroup(apiData);
      if (res?.status == true) {
        setGetuserData(res?.payload || []);
        setFilteredUserData(res?.payload || []);
      }
    } catch (error) {
      console.log('Member list response: ', error);
    }
  };

  const toggleSelectUser = (userId: any) => {
    setSelectedUsers((prevSelected) => {
      if (prevSelected.includes(userId)) {
        return prevSelected.filter((id: any) => id !== userId);
      } else {
        return [...prevSelected, userId];
      }
    });
    JoinComunityApi(userId)
  };

  const toggleSelectUserContact = (phoneNumber: string) => {
    setSelectedUsersContact((prevSelected) => {
      if (prevSelected.includes(phoneNumber)) {
        return prevSelected.filter((number: any) => number !== phoneNumber);
      } else {
        return [...prevSelected, phoneNumber];
      }
    });
  };

  const EventUserRegister = async () => {
    const userIds = selectedUsers.map(userId => userId);
    const apiData = { id: route?.params?.data?._id, token: userToken, userId: userIds };
    if (selectedUsersContact.length > 0) {
      sendBulkMessage();
    }
    navigation.goBack();
    // try {
    //   await requestEventUserRegister(apiData).then(async (res: any) => {
    //     navigation.goBack();
    //   });
    // } catch (error) {
    //   console.log('Event user register response: ', error);
    // }
  };



  const JoinComunityApi = async (userId: any) => {
    const data: any = {
      userId: userId,
      token: userToken,
      id: route?.params?.data?._id,
      type: 'events'
    };
    try {
      const res = await requestJoinClubAdd(data);
      console.log(res)
      if (res?.status == true) {
        const datas = { heading: 'login', message: res?.message };
        emitter.emit('alert', datas);
      } else {
        const data = {
          heading: 'failed',
          message: res?.message,
        };
        emitter.emit('alert', data);
      }
    } catch (error) {
      console.log('Follow user response: ', error);
    }
  };

  const sendBulkMessage = async () => {
    const getLink: any = await generateLink()
    const message = `Hi,\n${route?.params?.data?.title} admin has invited you to join fellow riders on MYTRA. Follow the link to connect: ${getLink} \n\nMYTRA `
    SendSMS.send({
      body: message,
      recipients: selectedUsersContact,
      successTypes: ['sent', 'queued'],
      allowAndroidSendWithoutReadPermission: true,
    }, (completed, cancelled, error) => {
      console.log('SMS Callback: completed: ' + completed + ' cancelled: ' + cancelled + 'error: ' + error);
    });
  };

  const generateLink = async () => {
    console.log(route?.params?.data)
    try {
      const link = await dynamicLinks().buildShortLink({
        link: `https://mytraclub.page.link/GMQ7?rideMemberAdd=${route?.params?.data?._id}`,
        domainUriPrefix: 'https://mytraclub.page.link',
        social: {
          title: `${route?.params?.data?.title}`,
          descriptionText: 'mytra.club',
          imageUrl: `${route?.params?.data?.files[0]?.url ? route?.params?.data?.files[0]?.url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNNLEL-qmmLeFR1nxJuepFOgPYfnwHR56vcw&s'}`
        },
        android: {
          packageName: 'com.thebikerscompany',
        },
        ios: {
          appStoreId: '6526488238',
          bundleId: 'com.mytra',
        },
      }, dynamicLinks.ShortLinkType.DEFAULT);
      return link;
    } catch (error) {
      console.log('Generating Link Error:', error);
    }
  };

  useEffect(() => {
    if (searchingText) {
      const lowercasedFilter = searchingText.toLowerCase();
      const filteredUserList = getuserData?.filter(item =>
        item?.full_name?.toLowerCase().includes(lowercasedFilter)
      ).filter(Boolean); // Filter out any undefined or null values
      setFilteredUserData(filteredUserList);

      const filteredContactList = contactData?.filter(item =>
      (item?.givenName?.toLowerCase().includes(lowercasedFilter) ||
        item?.familyName?.toLowerCase().includes(lowercasedFilter) ||
        item?.phoneNumbers?.some(phone => phone.number.includes(lowercasedFilter)))
      ).filter(Boolean); // Filter out any undefined or null values
      setFilteredContactData(filteredContactList);
    } else {
      setFilteredUserData(getuserData);
      setFilteredContactData(contactData);
    }
  }, [searchingText, getuserData, contactData]);





  const shareMessage = async () => {
    const getLink: any = await generateLink()
    const message = `Hi,\n${route?.params?.data?.title} admin has invited you to join fellow riders on MYTRA. Follow the link to connect: ${getLink} \n\nMYTRA `
    try {
      const result = await Share.share({
        message: message,
        // You can also specify a URL or title here if needed
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // Shared with activity type of result.activityType
          console.log('Shared with activity type:', result.activityType);
        } else {
          // Shared successfully
          console.log('Shared successfully');
        }
      } else if (result.action === Share.dismissedAction) {
        // Dismissed
        console.log('Share dismissed');
      }
    } catch (error: any) {
      console.error('Error sharing:', error.message);
    }
  };


  const handleTextChange = (newText: string) => {
    setSearchingText(newText);
    Getsearchdata(newText);
  };

  const Getsearchdata = async (text: string) => {
    const apiData = { token: userToken, searchText: text };
    setLoader(true);
    try {
      const res = await requestGetTagUserList(apiData);
      console.log(res)
      if (res?.status) {
        const result = res?.payload;
        if (text.length > 0) {
          setSearchData(result)
        } else {
          setSearchData([])
        }
      }
    } catch (error) {
      console.error('GET user list response: ', error);
    } finally {
      setLoader(false);
    }
  };

  const toggleSelectUserGlobal = (userId: any) => {
    setSelectedGlobalUser((prevSelected: any) => {
      if (prevSelected.includes(userId)) {
        return prevSelected.filter((id: any) => id !== userId);
      } else {
        return [...prevSelected, userId];
      }
    });
    JoinComunityApi(userId)
  };

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.black }}>
      <ScrollView style={styles.addcontainer} bounces={false}>
        <SafeAreaView />
        <View style={styles.addcontainer}>
          <View style={{ marginHorizontal: ms(2), marginVertical: ms(4) }}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <ArrowBAckIcon />
                </TouchableOpacity>
                <AppText
                  size={20}
                  color={COLORS.white}
                  family="PoppinsSemiB"
                  horizontal={20}>
                  Add Member
                </AppText>
              </View>
              <TouchableOpacity
                style={[styles.addButton]}
                onPress={() => EventUserRegister()}>
                <AppText
                  size={16}
                  color={COLORS.white}
                  align="center"
                  horizontal={3}
                  family={fonts.QuicksandBold}>
                  {'Done'}
                </AppText>
              </TouchableOpacity>
            </View>
            <View style={{ flexDirection: 'row', marginVertical: 20 }}>
              <View style={[styles.SearchBox]}>
                <View style={styles.inputBox}>
                  <TextInput
                    value={searchingText}
                    style={styles.input2}
                    placeholderTextColor={COLORS.grey92}
                    placeholder="Search"
                    onChangeText={text => handleTextChange(text)}
                    keyboardType="default"
                  />
                </View>
              </View>
            </View>

            <View style={{ marginVertical: 10 }}>
              <TouchableOpacity style={styles.InviteLink} onPress={shareMessage}>
                <View style={styles.link}>
                  <LinkIcon />
                </View>
                <AppText color='white' size={15} family='QuicksandBold'>    Invite to ride via link</AppText>
              </TouchableOpacity>
              {
                route?.params?.data?.clubId == null && searchData && searchData.length > 0 && (
                  <>
                    {
                      searchData.map((searchItem: any, index: number) => {
                        // if (route?.params?.data) {
                        //   let check = route?.params?.data.some((user: any) => user?.user_id === searchItem.id)
                        //   if (check == true) {
                        //     return
                        //   }
                        // }

                        return (
                          <TouchableOpacity
                            key={searchItem?.id}
                            style={styles.inviteContainer}
                            onPress={() => { toggleSelectUserGlobal(searchItem?.id) }}>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                              <Image
                                source={
                                  searchItem?.profile_picture == null
                                    ? require('../../../assets/img/profilepic.jpg')
                                    : { uri: searchItem?.profile_picture }
                                }
                                style={styles.item}
                              />
                              <AppText
                                size={16}
                                color={COLORS.whiteFBFB}
                                family={fonts.QuicksandSemi}
                                horizontal={15}>
                                {searchItem?.full_name}
                              </AppText>
                            </View>
                            <TouchableOpacity
                              onPress={() => { toggleSelectUserGlobal(searchItem?.id) }}
                              style={[
                                styles.inviteButton,
                                {
                                  backgroundColor: selectedGlobalUser.includes(searchItem?.id)
                                    ? COLORS.red
                                    : COLORS.blue,
                                },
                              ]}>
                              <AppText
                                size={16}
                                color={COLORS.white}
                                family={fonts.QuicksandBold}>
                                {selectedGlobalUser.includes(searchItem.id) ? 'Cancel' : 'Invite'}
                              </AppText>
                            </TouchableOpacity>
                          </TouchableOpacity>
                        )
                      })
                    }
                  </>
                )
              }
              {
                route?.params?.data?.groupId ? (
                  <>
                    {loader ? (
                      <View style={{ marginTop: ms(5) }}>
                        <ActivityIndicator size={50} color={COLORS.white} />
                      </View>
                    ) : (
                      filteredUserData?.filter(
                        (item) =>
                          !route?.params?.data?.registeredUsers.some(
                            (user) => user.id == item.id,
                          ),
                      )?.map((item, i) => {
                        console.log(item)
                        return (
                          <TouchableOpacity key={item?.id} style={styles.inviteContainer} onPress={() => toggleSelectUser(item?.id)}>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                              <Image
                                source={
                                  item?.profile_picture == null
                                    ? require('../../../assets/img/profilepic.jpg')
                                    : { uri: item?.profile_picture }
                                }
                                style={styles.item}
                              />
                              <AppText
                                size={16}
                                color={COLORS.whiteFBFB}
                                family={fonts.QuicksandSemi}
                                horizontal={15}>
                                {item?.full_name}
                              </AppText>
                            </View>
                            <TouchableOpacity
                              onPress={() => toggleSelectUser(item?.id)}
                              style={[
                                styles.inviteButton,
                                {
                                  backgroundColor: selectedUsers.includes(item?.id)
                                    ? COLORS.red
                                    : COLORS.blue,
                                },
                              ]}>
                              <AppText
                                size={16}
                                color={COLORS.white}
                                family={fonts.QuicksandBold}>
                                {selectedUsers.includes(item.id) ? 'Cancel' : 'Invite'}
                              </AppText>
                            </TouchableOpacity>
                          </TouchableOpacity>
                        );
                      })
                    )}
                  </>
                ) : (
                  <>
                    {loader ? (
                      <View style={{ marginTop: ms(5) }}>
                        <ActivityIndicator size={50} color={COLORS.white} />
                      </View>
                    ) : (
                      filteredUserData?.filter(
                        (item) =>
                          !route?.params?.data?.registeredUsers.some(
                            (user) => user?.user_id == item?.user_id,
                          ),
                      )?.map((item, i) => {
                        console.log(item)
                        return (
                          <TouchableOpacity key={item?.user_id} style={styles.inviteContainer} onPress={() => toggleSelectUser(item?.user_id)}>
                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                              <Image
                                source={
                                  item?.profile_picture == null
                                    ? require('../../../assets/img/profilepic.jpg')
                                    : { uri: item?.profile_picture }
                                }
                                style={styles.item}
                              />
                              <AppText
                                size={16}
                                color={COLORS.whiteFBFB}
                                family={fonts.QuicksandSemi}
                                horizontal={15}>
                                {item?.full_name}
                              </AppText>
                            </View>
                            <TouchableOpacity
                              onPress={() => toggleSelectUser(item?.user_id)}
                              style={[
                                styles.inviteButton,
                                {
                                  backgroundColor: selectedUsers.includes(item?.user_id)
                                    ? COLORS.red
                                    : COLORS.blue,
                                },
                              ]}>
                              <AppText
                                size={16}
                                color={COLORS.white}
                                family={fonts.QuicksandBold}>
                                {selectedUsers.includes(item.user_id) ? 'Cancel' : 'Invite'}
                              </AppText>
                            </TouchableOpacity>
                          </TouchableOpacity>
                        );
                      })
                    )}
                  </>
                )
              }

            </View>
            <View style={{ marginVertical: 5 }}>
              <AppText size={15} color='white' family='PoppinsMedium'>{route?.params?.data?.clubId ? '' : 'Invite from contacts:'}</AppText>
              <View style={{ marginVertical: 5 }} />
              {filteredContactData && (
                <>
                  {filteredContactData.map((item: any, index: number) => {
                    if (!item?.givenName || item?.givenName == "") {
                      return
                    }
                    return (
                      <TouchableOpacity key={item?.phoneNumbers[0]?.number + item?.givenName} style={styles.inviteContainer}>
                        <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1, paddingRight: 50 }}>
                          <FastImage
                            source={
                              item?.thumbnailPath
                                ? { uri: item?.thumbnailPath }
                                : require('../../../assets/img/profilepic.jpg')
                            }
                            style={styles.item}
                          />
                          <AppText
                            size={16}
                            color={COLORS.whiteFBFB}
                            family={fonts.QuicksandSemi}
                            horizontal={15} numLines={1} dotMode='tail'>
                            {item?.givenName} {item?.familyName}
                          </AppText>
                        </View>
                        <TouchableOpacity
                          onPress={() => toggleSelectUserContact(item?.phoneNumbers[0]?.number)}
                          style={[
                            styles.inviteButton,
                            {
                              backgroundColor: selectedUsersContact.includes(item?.phoneNumbers[0]?.number)
                                ? COLORS.red
                                : COLORS.blue,
                            },
                          ]}>
                          <AppText
                            size={16}
                            color={COLORS.white}
                            family={fonts.QuicksandBold}>
                            {selectedUsersContact.includes(item?.phoneNumbers[0]?.number) ? 'Cancel' : 'Invite'}
                          </AppText>
                        </TouchableOpacity>
                      </TouchableOpacity>
                    );
                  })}
                </>
              )}
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default AddEventMembersScreen;
