import { View, Text } from 'react-native'
import React from 'react'

const GroupBarPage = ({navigation, data}: any) => {
  return (
    <View>
      <Text>GroupBarPage</Text>
    </View>
  )
}

export default GroupBarPage