import React, {
  useCallback,
  useContext,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  View,
  TouchableOpacity,
  Animated,
  Modal,
  StyleSheet,
  FlatList,
  ScrollView,
  ActivityIndicator,
  Image,
  Text,
  TouchableWithoutFeedback,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Share,
  Alert,
} from 'react-native';
import { fonts } from '../../utils/misc';
import { COLORS, ms } from '../../style';
import {
  AddSOSIcon,
  ArrowBAckIcon,
  CommentIcon,
  CommentInactiveIcon,
  CrossRedIcon,
  LIkeICon,
  LikeIcon,
  LikeOutlineIcon,
  LikeOutlineWhiteIcon,
  LoveInactiveIcon,
  PostlikeICon,
  ShareInactiveIcon,
  ThreeDotInfo,
  WowIcon,
} from '../../assets/svgImg/SvgImg';
import { styles } from './styles';
import AppText from '../../component/AppText/AppText';
import ImgView from '../../component/ImgView/ImgView';
import {
  deletePost,
  requestCommentlist,
  requestCreateComment,
  requestFollowUser,
  requestGetDetails,
  requestPostList,
  requestPotlikeunlike,
  requestReport,
} from '../../services/api_Services';
import { AuthContext } from '../../component/auth/AuthContext';
import { useFocusEffect } from '@react-navigation/native';
import FastImage from 'react-native-fast-image';
// import Video from 'react-native-video';
import Skeleton from '../../component/Skeleton/Skeleton';
import ActionSheet, { ActionSheetRef } from 'react-native-actions-sheet';
import SubmitButton from '../../component/ButtonCotainer/SubmitButton';
import emitter from '../../component/Emitter/emitter';
import { reportData } from '../../component/data/mapdata';
import ActionView from './PostScreen/ActionView';
import BlockView from './PostScreen/BlockView';
import ReportView from './PostScreen/ReportView';
import CommentView from './PostScreen/CommentView';
import ShowMore from './ShowMore';
import dynamicLinks from '@react-native-firebase/dynamic-links';
import Video from 'react-native-video';
import Reactions from '../../component/EmojisAnimation/EmojisAnimation';
import DeletePostView from './PostScreen/DeletePostView';
import { LinkPreview } from '@flyerhq/react-native-link-preview';
import { shadowStyle } from '../../style/typography';


const PostView = ({ navigation, route, setScreenDat }: any) => {
  console.log(route?.params?.postId);

  const { userToken, userDetails }: any = useContext(AuthContext);
  const [cardData] = useState(new Array(3).fill(0));
  const [active, setActive] = useState();
  const [modalVisible, setModalVisible] = useState(false);
  const animation = useRef(new Animated.Value(0)).current;
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [skeletonLoader, setSkeletonLoader] = useState(false);
  const [userId, setUserId] = useState<any>();

  const actionSheetRef = useRef<ActionSheetRef>(null);
  const actionSheetRefComment = useRef<ActionSheetRef>(null);
  const [status, setStatus] = useState<boolean>(false);
  const [refreshing, setRefreshing] = useState(false);
  const [postlistData, setPostlistData] = useState<any>([]);
  const [screenData, setScreenData] = useState<any>(0);
  const [commentData, setCommentData] = useState<any>();
  const [seeMorePress, setSeeMorePress] = useState<any>([]);
  const commentInputRef = useRef<any>(null);
  const [focusedVideo, setFocusedVideo] = useState(null);
  const videoRefs = useRef<{ [key: string]: Video | null }>({});

  const [videoLoading, setVideoLoading] = useState(true);
  const [isBuffering, setIsBuffering] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  const [showReactions, setShowReactions] = useState<boolean>(false);
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [reaction, setReaction] = useState<string | null>(null);
  const [itemData, setItemData] = useState<string | null>();



  // const onScroll = useCallback(({viewableItems}) => {
  //   console.log(viewableItems, 'oooo');
  //   if (viewableItems.length > 0) {
  //     setFocusedVideo(viewableItems[0]?.item?._id);
  //   }
  // }, []);
  const onViewableItemsChanged = useRef(({ viewableItems }) => {
    if (viewableItems.length > 0) {
      const newFocusedVideo = viewableItems[0]?.item?._id;
      if (newFocusedVideo !== focusedVideo) {
        setFocusedVideo(newFocusedVideo);
      }
    }
  });

  useFocusEffect(
    useCallback(() => {
      GetPostList(page);
    }, []),
  );
  const GetPostList = async (page: any) => {
    let apiData;
    if (route?.params?.postId) {
      apiData = {
        login_user_id: userDetails?.id,
        token: userToken,
        page: page,
        id: route?.params?.postId,
      };
    } else {
      apiData = {
        login_user_id: userDetails?.id,
        token: userToken,
        page: page,
      };
    }
    setSkeletonLoader(true);
    try {
      const res = await requestPostList(apiData);
      if (res && res?.posts) {
        let result = res?.posts;
        console.log('3546456464564654564', result);
        for (let i = 0; i < result.length; i++) {
          result[i]['videoStatus'] = false;
          result[i]['imojiStatus'] = false;
        }
        if (page == 1) {
          // console.log(result);
          setPostlistData(result);
        } else {
          if (!route?.params?.postId) {
            setTimeout(() => {
              // setPostlistData((prevData: any) => [...prevData, ...res?.posts]);
              setPostlistData((prevData: any) => [...prevData, ...result]);
            }, 2000);
          }
        }
      } else {
        console.log('Invalid response structure:', res);
      }
      setLoading(false);
    } catch (error) {
      console.log('PostList response error: ', error);
    } finally {
      setSkeletonLoader(false);
      setLoading(false);
    }
  };
  const GetUserDetails = async (userId: any) => {
    const apiData = {
      user_id: userId,
      token: userToken,
      loginUserId: userDetails?.id,
    };
    try {
      await requestGetDetails(apiData).then(async (res: any) => {
        setStatus(res?.is_following);
      });
    } catch (error) {
      console.log('PostList response: ', error);
    }
  };
  const GetCommentList = async (postId: any) => {
    const apiData = {
      postId: postId,
      token: userToken,
    };
    console.log(postId);
    try {
      await requestCommentlist(apiData).then(async (res: any) => {
        console.log(res, 'ress');
        setCommentData(res);
      });
    } catch (error) {
      console.log('PostList response: ', error);
    }
  };
  const UserFollowApi = async (status: any) => {
    const data: any = {
      follower_id: userDetails?.id,
      token: userToken,
      following_id: userId?.user?.id,
      action: status,
    };
    try {
      const res = await requestFollowUser(data);
      console.log(res, 'res');
      const datas = { heading: 'login', message: res?.message };
      emitter.emit('alert', datas);
      actionSheetRef.current?.hide();
      if (status == 'block') {
        console.log('ss');
        GetPostList(1);
      }
    } catch (error) {
      console.log('Follow user response: ', error);
    }
  };
  const ReportApi = async (report_text: any) => {
    const data: any = {
      user_id: userDetails?.id,
      token: userToken,
      post_id: userId?._id,
      report_text: report_text,
    };
    try {
      const res = await requestReport(data);
      const datas = { heading: 'login', message: res?.message };
      emitter.emit('alert', datas);
      actionSheetRef.current?.hide();
      GetPostList(1);
    } catch (error) {
      console.log('Follow user response: ', error);
    }
  };

  const DeletePostApi = async () => {
    console.log("post ", userId)
    GetPostList(1);
    const data: any = {
      token: userToken,
      post_id: userId?._id
    };
    try {
      const res = await deletePost(data);
      const datas = { heading: 'login', message: res?.message };
      emitter.emit('alert', datas);
      actionSheetRef.current?.hide();
      GetPostList(1);
      setPostlistData((prevPosts: any) => prevPosts.filter((post: any) => post._id !== userId?._id));
    } catch (error) {
      console.log('Delete Post response: ', error);
      actionSheetRef.current?.hide();
      GetPostList(1);
    }
    if (route?.params?.postId) {
      navigation.goBack()
    }
  };

  const CancelDeletePost = () => {
    actionSheetRef.current?.hide();
    GetPostList(1);
  }

  const handleImagePress = (data: any) => {
    setActive(data);
    setModalVisible(true);
    Animated.timing(animation, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  const handleImageClose = () => {
    Animated.timing(animation, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setModalVisible(false);
    });
  };

  const animatedStyle = {
    opacity: animation,
    transform: [{ scale: animation }],
  };

  function getFirst200Words(text: any) {
    let words = text.split(/\s+/);
    let first100Words = words.slice(0, 25);
    return first100Words.join(' ');
  }

  const PostLikeapi = async (postID: any, status: any, like: any) => {
    const updatedUsers = postlistData.map((user: any) => ({
      ...user,
      imojiStatus: false,
    }));
    setPostlistData(updatedUsers);
    setShowReactions(false);
    console.log("likelikelike", like)
    const data = {
      user: userDetails?.id,
      emoji: like == "like" ? 2 : like == 'wow' ? 3 : like == 'haha' ? 4 : like == 'sad' ? 5 : "like",
    };
    try {
      await requestPotlikeunlike(data, postID, userToken).then(res => {
        const updatedPostlistData = postlistData.map((post: any) => {
          if (post._id == postID) {
            return {
              ...post,
              isLikedByUser: status,
              likeCount: status ? post?.likeCount + 1 : post?.likeCount - 1,
            };
          }
          return post;
        });
        setPostlistData(updatedPostlistData);
      });
    } catch (error) {
      console.log('Create group response: ', error);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setPage(1);
    GetPostList(1);
    setRefreshing(false);
  };
  const handleBlankCore = () => { };
  const handleLoadMore = () => {
    console.log('footer');
    setLoading(true);
    if (!loading) {
      let dpage = page + 1;
      setPage(prevPage => prevPage + 1);
      GetPostList(dpage);
    }
  };
  // ----------COMMENT PRESS----------
  const handleCommentPress = (item: any) => {
    GetCommentList(item?._id);
    setUserId(item);
    actionSheetRefComment?.current?.show();
    commentInputRef?.current?.focus();
  };

  const shareMessage = async (item: any) => {
    console.log(item?._id, 'item?._id')
    const getLink: any = await generateLink(item);
    console.log(getLink, 'iiiiii');
    try {
      const result = await Share.share({
        message: getLink,
        // You can also specify a URL or title here if needed
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // Shared with activity type of result.activityType
          console.log('Shared with activity type:', result.activityType);
        } else {
          // Shared successfully
          console.log('Shared successfully');
        }
      } else if (result.action === Share.dismissedAction) {
        // Dismissed
        console.log('Share dismissed');
      }
    } catch (error: any) {
      console.error('Error sharing:', error.message);
    }
  };

  const generateLink = async (postId: any) => {
    try {
      const link = await dynamicLinks().buildShortLink(
        {
          link: `https://mytraclub.page.link/r394?postId=${postId?._id}`,
          domainUriPrefix: 'https://mytraclub.page.link',
          social: {
            title: `Post from ${postId?.user?.user_name}`,
            descriptionText: 'mytra.club',
            imageUrl: `${postId?.files[0]?.url ? postId?.files[0]?.url : 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNNLEL-qmmLeFR1nxJuepFOgPYfnwHR56vcw&s'}`
          },
          android: {
            packageName: 'com.thebikerscompany',
          },
          ios: {
            appStoreId: '6526488238',
            bundleId: 'com.mytra',
          },
        },
        dynamicLinks.ShortLinkType.DEFAULT,
      );
      console.log('link:', link);
      return link;
    } catch (error) {
      console.log('Generating Link Error:', error);
    }
  };


  const renderTagUsers = (item: any) => {
    console.log('itemitemitemitemitem', item)
    if (item?.tags?.length > 0) {
      return (
        <View style={styles.mentionContainer}>
          {item.tags.map((user: any, index: any) => (
            <TouchableOpacity key={index} activeOpacity={0.6} onPress={() => {
              navigation.navigate('Profile', {
                id: item?.user?.id,
              })
            }}>
              <Text style={styles.mention}>{`@${user.user_name} `}</Text>
            </TouchableOpacity>
          ))}
        </View>
      );
    }

  };

  // ----------VIDEO----------
  const onVideoLoad = () => {
    setVideoLoading(false);
    setIsBuffering(false);
    console.log('Video loaded successfully');
  };
  const toggleMute = () => {
    if (videoRefs.current) {
      videoRefs.current.setMuted(!isMuted);
      setIsMuted(!isMuted);
    }
  };
  useEffect(() => {
    const unsubscribe = navigation.addListener('blur', () => {
      if (focusedVideo) {
        videoRefs.current[focusedVideo]?.pause();
        setFocusedVideo(null);
      }
    });
    return unsubscribe;
  }, [navigation, focusedVideo]);

  useFocusEffect(
    React.useCallback(() => {
      return () => {
        if (focusedVideo) {
          videoRefs.current[focusedVideo]?.pause();
          setFocusedVideo(null);
        }
      };
    }, [focusedVideo])
  );

  const RenderItem = React.memo(({ item, index }: any) => {
    // const videoRef: any = useRef(null);

    // useEffect(() => {
    //   if (item?._id === focusedVideo) {
    //     videoRef?.current?.playAsync();
    //   } else {
    //     videoRef?.current?.pauseAsync();
    //   }
    // }, [item?._id === focusedVideo]);

    //  console.log(item.tags, 'dd');


    // const handleReactionSelect = (reactionName: string, item: any) => {
    //   console.log('Selected reaction:', reactionName);
    //   setReaction(reactionName);
    //   setShowReactions(false);
    //   PostLikeapi(item?._id, true, reactionName);
    // };

    const handleReactionSelect = (reactionName: string) => {
      console.log('Selected reaction:', reactionName, itemData);
      setReaction(reactionName);
      setShowReactions(false);
      const updatedUsers = postlistData.map((user: any) => ({
        ...user,
        imojiStatus: false,
      }));
      setPostlistData(updatedUsers);
      console.log(updatedUsers)
      PostLikeapi(itemData?._id, true, reactionName);
    };


    const onImoji = (item: any, index: any) => {
      setItemData(item)
      const updatedUsers = postlistData.map((item: any, selectedIndex: any) => ({
        ...item,
        imojiStatus: selectedIndex === index ? !item.imojiStatus : false
      }));
      setPostlistData(updatedUsers)
      setShowReactions(true);
    };

    const text = item?.description;

    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const urls = text?.match(urlRegex);
    console.log(urls, 'oodododododododdodododod')
    if (urls) {

    } else {
      // console.log("No URLs found in the text.");
    }

    useEffect(() => {
      // getLinkPreview("https://www.youtube.com/watch?v=MejbOFk7H6c").then((data) =>
      //   console.debug(data)
      // );
    }, [])

    const handlePreviewDataFetched = (previewData: any) => {
      console.log('Preview data fetched:', previewData);
    };
    const areAllEmojisSame = item?.lastThreeLikes?.every((icon: any) => icon.emoji === item?.lastThreeLikes[0]?.emoji);
    return (
      <View style={styles.postView}>
        <View style={styles.everyPostView}>
          <View style={[styles.userDetails, { width: '90%', alignSelf: 'center' }]}>
            <TouchableOpacity activeOpacity={1}
              style={[styles.userDetails, {}]}
            >
              <TouchableOpacity onPress={() => {
                navigation.navigate('Profile', {
                  id: item?.user?.id,
                });
                // setScreenDat(0);
              }}>
                <ImgView
                  height={40}
                  width={40}
                  radius={50}
                  dummy={true}
                  // url={item?.user?.profile_picture ? item?.user?.profile_picture:require('../../assets/img/profilepic.jpg')}
                  url={
                    item?.user?.profile_picture
                      ? { uri: item?.user?.profile_picture }
                      : require('../../assets/img/profilepic.jpg')
                  }
                />
              </TouchableOpacity >
              <View style={[styles.nameUserName, { paddingLeft: 12, paddingRight: 0 }]}>
                <AppText
                  size={16}
                  family="PoppinsSemiB"
                  color="white"
                  numLines={1}
                  dotMode="tail">
                  {item?.user?.full_name}
                </AppText>
                {/* <AppText
                  size={13}
                  family="PoppinsRegular"
                  color={COLORS.mediumgray}
                  numLines={1}
                  dotMode="tail">
                  {item?.user?.user_name
                    ? `${item?.user?.user_name} \u2022 `
                    : null}
                  {item?.postCreationTime}
                </AppText> */}
                <View style={{ flexDirection: 'row', alignItems: 'center', width: '99%', justifyContent: 'space-between' }}>

                  <AppText
                    size={13}
                    family="PoppinsRegular"
                    color={COLORS.mediumgray}
                    numLines={1}
                    dotMode="tail"
                    width={'60%'}
                    maxWidth={'60%'}>
                    {item?.location != '' ? '' : item?.location}
                  </AppText>

                  <AppText
                    size={13}
                    family="PoppinsRegular"
                    color={COLORS.mediumgray}
                    align='right'
                  >
                    {item?.postCreationTime}
                  </AppText>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.infoIcon}
              onPress={() => {
                setTimeout(() => {
                  GetUserDetails(item?.user?.id);
                }, 100);
                // setScreenDat(0);
                setUserId(item);
                actionSheetRef.current?.show();
              }}>
              <ThreeDotInfo />
            </TouchableOpacity>

          </View>


          {/* {(item?.color.length == 0 && item?.description )&& (
            <ShowMore description={item?.description} />
          )} */}
          <View style={{ width: '100%', alignSelf: 'center' }}>
            {item?.description ?
              ((item?.color.length > 0 && item?.color[0] !== '#111111' && item?.color[0] !== '') ? (
                <>
                  {renderTagUsers(item)}
                  <View
                    style={[styles.TextBackgroundBox, {
                      backgroundColor:
                        item.color.length > 0 ? item.color[0] : COLORS.black131,
                    }]}>
                    <AppText
                      size={27}
                      family="PoppinsSemiB"
                      color={
                        item.color[0] !== '#FFFFFF' ? COLORS.white : COLORS.black
                      }>
                      {item?.description}
                    </AppText>
                  </View>
                </>
              )
                :
                <>
                  <View style={{ width: '90%', alignSelf: 'center' }}>
                    <ShowMore description={item?.description} />

                  </View>
                  {renderTagUsers(item)}
                </>
              )
              :
              <>
                {renderTagUsers(item)}
              </>
            }
            {
              urls && (
                <>
                  {
                    urls.map((url: any) => {
                      return (
                        <>
                          {url ? (
                            <View style={{ marginTop: 5 }}>
                              <LinkPreview
                                text={url}
                                onPreviewDataFetched={handlePreviewDataFetched}
                                renderText={(text) => <Text style={styles.descriptionText}>{text}</Text>}
                                // renderTitle={text => (
                                //   <Text style={styles.descriptionText}>{text}</Text>
                                // )}
                                containerStyle={[styles.previewContainer, shadowStyle]}
                                renderDescription={text => <Text style={styles.descriptionText}>{text}</Text>}
                                renderImage={previewData => (
                                  <Image
                                    source={{ uri: previewData?.url }}
                                    style={styles.image2}
                                    resizeMode="contain"
                                  />
                                )}
                              />
                            </View>
                          ) : null}

                        </>
                      )
                    })
                  }
                </>
              )
            }
          </View>


          {item?.files.length > 0 &&
            (item?.files[0]?.type === 'video' ? (
              <>
                {videoLoading && (
                  <ActivityIndicator
                    style={{
                      position: 'absolute',
                      top: '50%',
                      left: '45%',
                      zIndex: 1,
                    }}
                    size="large"
                    color={COLORS.white}
                  />
                )}
                <TouchableOpacity
                  activeOpacity={1}
                  onPress={() => { }}
                  style={{
                    width: '100%',
                    height: 400,
                    marginBottom: 12,
                    marginTop: 15,
                  }}>
                  <Video
                    ref={ref => (videoRefs.current[item._id] = ref)}
                    source={{ uri: item.files[0]?.url }}
                    style={{
                      width: '100%',
                      height: 400,
                      // borderRadius: 10,
                      // overflow: 'hidden',
                    }}
                    resizeMode="cover"
                    repeat={true}
                    paused={item._id !== focusedVideo}
                    onLoad={onVideoLoad}
                    // muted={isMuted}
                    poster={''}
                  />
                  {/* <TouchableOpacity
                    style={{
                      position: 'absolute',
                      top: 20,
                      right: 20,
                      backgroundColor: 'rgba(0, 0, 0, 0.5)',
                      padding: 10,
                      borderRadius: 5,
                    }}
                    onPress={()=>toggleMute()}>
                    <Text style={{color: 'white'}}>
                      {isMuted ? 'Unmute' : 'Mute'}
                    </Text>
                  </TouchableOpacity> */}
                </TouchableOpacity>
              </>
            ) : (
              <TouchableOpacity
                onPress={() => handleImagePress(item?.files[0]?.url)}
                style={{ marginBottom: 12, marginTop: 15 }}
                activeOpacity={0.9}>
                <ImgView
                  height={400}
                  width={'100%'}
                  url={item?.files[0]?.url}
                  mode="contain"
                // radius={10}
                />
              </TouchableOpacity>
            ))
          }
          <View style={[styles.photoStatus, { marginTop: (item?.likeCount > 0 || item?.commentCount > 0) ? 10 : 0 }]}>
            <View style={styles.emojiContainer}>
              {item?.likeCount > 0 && <LikeOutlineWhiteIcon />}
              {/* //  : (
              //   <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              //     {areAllEmojisSame ? (
              //       item?.lastThreeLikes[0]?.emoji === 2 && (
              //         <LikeIcon />
              //       )
              //     ) : (
              //       item?.lastThreeLikes.map((icon: any, index: any) => (
              //         <View key={index} style={{ marginHorizontal: -4 }}>
              //           {icon?.emoji === 2 && (
              //             <LikeIcon />
              //           )}
              //         </View>
              //       ))
              //     )}
              //   </View>
              // )} */}

              {item?.commentCount > 0 && <CommentIcon />}
            </View>
            {/* <View style={{ marginHorizontal: 12 }}>
              <AppText
                numLines={1}
                dotMode="tail"
                size={13}
                color={COLORS.grey90}
                family={'PoppinsRegular'}>
                {item?.likeCount > 0 ? `${item?.likeCount} Likes` : null}{' '}
                {item?.commentCount > 0 ? `\u2022 ${item?.commentCount} Comments` : null}
              </AppText>
            </View> */}
            <View
              style={{
                marginHorizontal: 12,
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <AppText
                numLines={1}
                dotMode="tail"
                size={13}
                color={COLORS.grey90}
                family={'PoppinsRegular'}>
                {item?.likeCount > 0
                  ? `${item?.likeCount} ${item?.likeCount === 1 ? 'Like' : 'Likes'
                  }`
                  : null}{' '}
              </AppText>
              <TouchableOpacity
                activeOpacity={1}
                onPress={() => handleCommentPress(item)}>
                <AppText
                  numLines={1}
                  dotMode="tail"
                  size={13}
                  color={COLORS.grey90}
                  family={'PoppinsRegular'}>
                  {item?.commentCount > 0 ? (
                    <>
                      <Text style={styles.smallBullet}>
                        {item?.likeCount > 0 ? '\u2022' : ''}
                      </Text>{' '}
                      {`${item?.commentCount} ${item?.commentCount === 1 ? 'Comment' : 'Comments'
                        }`}
                    </>
                  ) : null}
                </AppText>
              </TouchableOpacity>
            </View>
          </View>
          <View style={[styles.photoStatus, styles.likecommentShare, { marginTop: (item?.likeCount > 0 || item?.commentCount > 0) ? 15 : 0 }]}>


            {item?.isLikedByUser === false ? (
              <TouchableOpacity onLongPress={() => onImoji(item, index)}
                onPress={() => {
                  PostLikeapi(item?._id, true, 'like');
                }}>
                <LikeOutlineIcon />
              </TouchableOpacity>
            ) : (

              <TouchableOpacity
                onPress={() => {
                  PostLikeapi(item?._id, false, 'like');
                }}>
                <LikeIcon />
              </TouchableOpacity>
            )}

            <TouchableOpacity
              onPress={() => {
                GetCommentList(item?._id);
                setUserId(item);
                actionSheetRefComment?.current?.show();
                commentInputRef?.current?.focus();
              }}>
              <CommentInactiveIcon />
            </TouchableOpacity>

            <TouchableOpacity onPress={() => shareMessage(item)}>
              <ShareInactiveIcon />
            </TouchableOpacity>
          </View>
          {(item?.imojiStatus && showReactions) && (
            <Reactions onReactionSelect={handleReactionSelect} />
          )}
        </View>
      </View>
    );
  });

  return (
    <>
      <View
        style={{ flex: 1, paddingBottom: 100, backgroundColor: COLORS.black }}>
        <FlatList
          data={postlistData}
          bounces={false}
          nestedScrollEnabled={true}
          renderItem={({ item, index }) => <RenderItem item={item} index={index} />}
          keyExtractor={(item, index) => index.toString()}
          onEndReached={
            route?.params?.postId ? handleBlankCore : handleLoadMore
          }
          onEndReachedThreshold={0.1}
          snapToAlignment="start"
          // onViewableItemsChanged={onScroll}
          decelerationRate="fast"
          onViewableItemsChanged={onViewableItemsChanged.current}
          viewabilityConfig={{ viewAreaCoveragePercentThreshold: 50 }}
          // viewabilityConfig={{
          //   itemVisiblePercentThreshold: 50,
          // }}
          ListEmptyComponent={() => (
            <View style={{ flex: 1 }}>
              {cardData.map((_, index) => (
                <View
                  key={index}
                  style={{ marginVertical: 15, marginHorizontal: 20 }}>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}>
                    <Skeleton
                      type="circle"
                      height={50}
                      width={50}
                      borderRadius={50}
                    />
                    <View style={styles.nameUserName}>
                      <Skeleton type="box" height={25} width={130} />
                    </View>
                    <Skeleton
                      type="circle"
                      height={8}
                      width={8}
                      borderRadius={50}
                    />
                    <Skeleton
                      type="circle"
                      height={8}
                      width={8}
                      borderRadius={50}
                    />
                    <Skeleton
                      type="circle"
                      height={8}
                      width={8}
                      borderRadius={50}
                    />
                  </View>
                  <Skeleton
                    type="box"
                    height={250}
                    width={'100%'}
                    style={{ marginTop: 20 }}
                  />
                </View>
              ))}
            </View>
          )}
          refreshing={refreshing}
          onRefresh={handleRefresh}
          ListFooterComponent={
            loading ? (
              <View style={{ marginTop: 80 }}>
                <ActivityIndicator size={50} color={COLORS.white} />
              </View>
            ) : null
          }
        />
        {active && (
          <Modal transparent visible={modalVisible}>
            <TouchableOpacity
              style={StyleSheet.absoluteFill}
              onPress={handleImageClose}>
              <Animated.View style={[styles.overlayBG, animatedStyle]} />
            </TouchableOpacity>
            <Animated.View style={[styles.modalContent, animatedStyle]}>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={handleImageClose}>
                <CrossRedIcon />
              </TouchableOpacity>
              <FastImage
                source={{ uri: active }}
                style={styles.img}
                resizeMode={FastImage.resizeMode.contain}
              />
            </Animated.View>
          </Modal>
        )}
        <ActionSheet
          ref={actionSheetRef}
          headerAlwaysVisible={true}
          onClose={() => {
            actionSheetRef.current?.hide();
            setScreenData(0);
          }}
          indicatorStyle={styles.indicator}
          containerStyle={
            screenData == 2 ? styles.actionContainer2 : styles.actionContainer
          }>
          {screenData == 0 ? (
            <ActionView
              actionSheetRef={actionSheetRef}
              status={status}
              UserFollowApi={UserFollowApi}
              navigation={navigation}
              userId={userId}
              userDetails={userDetails}
              setScreenData={setScreenData}
            />
          ) : screenData == 1 ? (
            <BlockView
              actionSheetRef={actionSheetRef}
              UserFollowApi={UserFollowApi}
              userId={userId}
              setScreenData={setScreenData}
            />
          ) : screenData == 2 ? (
            <ReportView ReportApi={ReportApi} />
          ) : screenData == 3 ? (
            <DeletePostView
              actionSheetRef={actionSheetRef}
              UserFollowApi={DeletePostApi}
              userId={userId}
              setScreenData={CancelDeletePost}
            />
          )
            : null}
        </ActionSheet>
        <ActionSheet
          ref={actionSheetRefComment}
          headerAlwaysVisible={true}
          animated={true}
          indicatorStyle={styles.indicator}
          containerStyle={styles.actionContainer2}>
          <CommentView
            userId={userId}
            commentData={commentData}
            GetCommentList={GetCommentList}
            commentInputRef={commentInputRef}
          />
        </ActionSheet>

      </View>
    </>
  );
};

export default PostView;

// import React, {useRef, useState, useEffect} from 'react';
// import {
//   View,
//   ActivityIndicator,
//   StyleSheet,
//   FlatList,
//   TouchableOpacity,
//   Text,
//   Image,
// } from 'react-native';
// import Video from 'react-native-video';
// import {height} from '../../style/typography';

// const YourComponent = ({navigation}: any) => {
//   const flatlistRef = useRef(null); // Ref for FlatList
//   const [videos, setVideos] = useState<any>();
//   const [loading, setLoading] = useState(true); // State to track video loading
//   const [currentVideoIndex, setCurrentVideoIndex] = useState(null); // State to track currently playing video index
//   useEffect(() => {
//     // Function to fetch video data from API

//     fetchVideoData();
//   }, []); // Empty dependency array means this effect runs only once after initial render
//   const fetchVideoData = async () => {
//     try {
//       // Replace with your actual API endpoint
//       const response = await fetch(
//         'http://3.111.234.55:6005/post/post-list?login_user_id=26&page=1&limit=20',
//       );
//       const data = await response.json();
//       // Initialize playing status based on API response
//       const initialVideos = data?.posts?.map((video, index) => ({
//         ...video,
//         playing: false, // Initial state can be fetched from API if available
//       }));
//       setVideos(initialVideos);
//       setLoading(false);
//     } catch (error) {
//       console.error('Error fetching video data:', error);
//       setLoading(false);
//     }
//   };
//   const viewStyle = StyleSheet.create({
//     videoContainer: {
//       width: '100%',
//       height: height / 1,
//     },
//     playButton: {
//       position: 'absolute',
//       alignSelf: 'center',
//       top: '45%',
//       zIndex: 1,
//     },
//     playButtonText: {
//       color: 'white',
//       fontSize: 20,
//     },
//   });
//   console.log(videos, 'videos',currentVideoIndex);
//   useEffect(() => {
//     if (currentVideoIndex !== null && flatlistRef.current) {
//       // Pause all videos except the one that is playing
//       const updatedVideos = videos.map((video, index) => ({
//         ...video,
//         playing: index == currentVideoIndex,
//       }));
//       setVideos(updatedVideos);
//     }
//   }, [currentVideoIndex]);

//   console.log(videos, 'videos22',currentVideoIndex);

//   const togglePlay = index => {
//     setCurrentVideoIndex(index);
//   };

//   const onViewableItemsChanged = useRef(({viewableItems}) => {
//     // Pause all videos that are not in view
//     console.log(viewableItems, 'viewableItems');
//     const visibleIndexes = viewableItems.map(item => item.index);
//     const updatedVideos = videos?.map((video, index) => ({
//       ...video,
//       playing: visibleIndexes.includes(index),
//     }));
//     setVideos(updatedVideos);
//   }).current;

//   const renderItem = ({item, index}) => {
//     return (
//       <View style={{flex: 1, backgroundColor: 'red'}}>
//         {
//      item?.files.length > 0 &&
//                (item?.files[0]?.type == 'photo' ? (
//           <Image
//             source={{uri: item.files[0]?.url}}
//             style={{height:300,width:300}}
//           />
//         ) : (
//           <>
//             <Video
//               source={{uri: item.files[0]?.url}}
//               style={viewStyle.videoContainer}
//               controls={false}
//               resizeMode="cover"
//               onLoad={() => setLoading(false)}
//               onError={error => console.error('Video playback error:', error)}
//               repeat={true}
//               paused={!item.playing}
//             />
//             {!item.playing && (
//               <TouchableOpacity
//                 style={viewStyle.playButton}
//                 onPress={() => togglePlay(index)}>
//                 <Text style={viewStyle.playButtonText}>Play</Text>
//               </TouchableOpacity>
//             )}
//             {loading && (
//               <View style={StyleSheet.absoluteFillObject}>
//                 <ActivityIndicator size="large" color="#ffffff" />
//               </View>
//             )}
//           </>
//         ))}
//       </View>
//     );
//   };

//   return (
//     <FlatList
//       ref={flatlistRef}
//       data={videos}
//       renderItem={renderItem}
//       keyExtractor={item => item.id}
//       onViewableItemsChanged={onViewableItemsChanged}
//       viewabilityConfig={{viewAreaCoveragePercentThreshold: 50}} // Adjust as needed
//     />
//   );
// };

// export default YourComponent;

// import React, { useRef, useState, useEffect } from 'react';
// import { View, ActivityIndicator, StyleSheet, FlatList, TouchableOpacity, Text } from 'react-native';
// import Video from 'react-native-video';
// import { height } from '../../style/typography';

// const YourComponent = ({navigation}:any) => {
//   const flatlistRef = useRef(null); // Ref for FlatList
//   const [videos, setVideos] = useState([
//     { id: 1, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4', playing: false },
//     { id: 2, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4', playing: false },
//     { id: 3, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', playing: false },
//     { id: 4, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4', playing: false },
//     { id: 5, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4', playing: false },
//     { id: 6, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4', playing: false },
//     { id: 7, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4', playing: false },
//     { id: 8, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4', playing: false },
//     { id: 9, uri: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4', playing: false },
//     // Add more video URIs as needed
//   ]);
//   const [loading, setLoading] = useState(true); // State to track video loading
//   const [currentVideoIndex, setCurrentVideoIndex] = useState(null); // State to track currently playing video index

//   const viewStyle = StyleSheet.create({
//     videoContainer: {
//       width: '100%',
//       height:  height/1
//     },
//     playButton: {
//       position: 'absolute',
//       alignSelf: 'center',
//       top: '45%',
//       zIndex: 1,
//     },
//     playButtonText: {
//       color: 'white',
//       fontSize: 20,
//     },
//   });

//   useEffect(() => {
//     if (currentVideoIndex !== null && flatlistRef.current) {
//       // Pause all videos except the one that is playing
//       const updatedVideos = videos.map((video, index) => ({
//         ...video,
//         playing: index === currentVideoIndex,
//       }));
//       setVideos(updatedVideos);
//     }
//   }, [currentVideoIndex]);

//   const togglePlay = (index) => {
//     setCurrentVideoIndex(index);
//   };

//   const onViewableItemsChanged = useRef(({ viewableItems }) => {
//     // Pause all videos that are not in view
//     const visibleIndexes = viewableItems.map(item => item.index);
//     const updatedVideos = videos.map((video, index) => ({
//       ...video,
//       playing: visibleIndexes.includes(index),
//     }));
//     setVideos(updatedVideos);
//   }).current;

//   const renderItem = ({ item, index }) => {
//     return (
//       <View style={{flex:1,backgroundColor:'red'}}>
//         <Video
//           source={{ uri: item.uri }}
//           style={viewStyle.videoContainer}
//           controls={false}
//           resizeMode='cover'
//           onLoad={() => setLoading(false)}
//           onError={(error) => console.error('Video playback error:', error)}
//           repeat={true}
//           paused={!item.playing}
//         />
//         {!item.playing && (
//           <TouchableOpacity style={viewStyle.playButton} onPress={() => togglePlay(index)}>
//             <Text style={viewStyle.playButtonText}>Play</Text>
//           </TouchableOpacity>
//         )}
//         {loading && (
//           <View style={StyleSheet.absoluteFillObject}>
//             <ActivityIndicator size="large" color="#ffffff" />
//           </View>
//         )}
//       </View>
//     );
//   };

//   return (
//     <FlatList
//       ref={flatlistRef}
//       data={videos}
//       renderItem={renderItem}
//       keyExtractor={(item) => item.id.toString()}
//       onViewableItemsChanged={onViewableItemsChanged}
//       viewabilityConfig={{ viewAreaCoveragePercentThreshold: 50 }} // Adjust as needed
//     />
//   );
// };

// export default YourComponent;
