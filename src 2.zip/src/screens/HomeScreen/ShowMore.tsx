import { View, Text, TouchableOpacity, Image } from 'react-native'
import React, { useEffect, useState } from 'react'
import { styles } from './styles'
import AppText from '../../component/AppText/AppText'
import { COLORS } from '../../style'
import { LinkPreview } from '@flyerhq/react-native-link-preview'
import { shadowStyle } from '../../style/typography'
// import { getLinkPreview, getPreviewFromContent } from "link-preview-js";

const ShowMore = ({ description }: any) => {
  const [showMore, setShowMore] = useState(false);
  const [urlView, setUrlView] = useState(false);

  const text = description;

  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const urls = text?.match(urlRegex);
  console.log(urls, 'oodododododododdodododod')
  if (urls) {

  } else {
    // console.log("No URLs found in the text.");
  }

  useEffect(() => {
    // getLinkPreview("https://www.youtube.com/watch?v=MejbOFk7H6c").then((data) =>
    //   console.debug(data)
    // );
  }, [])

  const handlePreviewDataFetched = (previewData: any) => {
    console.log('Preview data fetched:', previewData);
  };

  return (
    <View style={styles.postDesc}>
      <AppText size={14} numLines={showMore ? 0 : 3} dotMode='tail' family="PoppinsRegular" color={COLORS.whiteEB}>
        {description}
        {/* {item?.description.length < 40
        ? item?.description
        : `${getFirst200Words(item?.description)}...`} */}
      </AppText>
      {description.length > 70 ? (
        <TouchableOpacity onPress={() => {
          setShowMore(!showMore)
        }}>

          <AppText
            size={14}
            family="PoppinsRegular"
            color={COLORS.lightyellow}>
            {showMore ? "Read less" : "Read more"}
          </AppText>
        </TouchableOpacity>)
        : (
          null
        )
      }
      


    </View>
  )
}

export default ShowMore




// import React, {useEffect, useState} from 'react';
// import {View, Text, TouchableOpacity, Image, StyleSheet} from 'react-native';
// import AppText from '../../component/AppText/AppText';
// import {COLORS} from '../../style';
// import {LinkPreview} from '@flyerhq/react-native-link-preview';
// import {styles} from './styles';
// import { shadowStyle } from '../../style/typography';

// const ShowMore = ({description}: any) => {
//   const [showMore, setShowMore] = useState(false);
//   const [pastedUrl, setPastedUrl] = useState('');

//   const text = description;
//   const urlRegex = /(https?:\/\/[^\s]+)/g;
//   const urls = text?.match(urlRegex);

//   useEffect(() => {
//     if (urls && urls.length > 0) {
//       // Assuming you want to show the preview for the first URL
//       setPastedUrl(urls[0]);
//     }
//   }, [urls]);

//   const handlePreviewDataFetched = (previewData: any) => {
//     console.log('Preview data fetched:', previewData);
//   };

//   return (
//     <View style={styles.postDesc}>
//       {!pastedUrl && (
//         <AppText
//           size={14}
//           numLines={showMore ? 0 : 3}
//           dotMode="tail"
//           family="PoppinsRegular"
//           color={COLORS.whiteEB}>
//           {description}
//         </AppText>
//       )}

//       {description.length > 70 ? (
//         <TouchableOpacity onPress={() => setShowMore(!showMore)}>
//           <AppText size={14} family="PoppinsRegular" color={COLORS.lightyellow}>
//             {showMore ? 'Read less' : 'Read more'}
//           </AppText>
//         </TouchableOpacity>
//       ) : null}


//     </View>
//   );
// };

// export default ShowMore;
