import { View, Text, ScrollView, TouchableOpacity } from 'react-native'
import React, { useContext, useEffect, useState } from 'react'
import { styles } from './styles'
import { getAllRequestList, getAllRequestListAdmin, requestJoinAcceptReject } from '../../services/api_Services'
import { AuthContext } from '../../component/auth/AuthContext'
import ImgView from '../../component/ImgView/ImgView'
import { COLORS, ms } from '../../style'
import AppText from '../../component/AppText/AppText'
import emitter from '../../component/Emitter/emitter'

const NotificationList = () => {
  const { userToken, userDetails }: any = useContext(AuthContext);
  const [notification, setNotification] = useState<any>()
  const [notificationAdmin, setNotificationAdmin] = useState<any>()
  useEffect(() => {
    Getgroupdetails()
    GetgroupdetailsAdmin()
  }, [])

  const Getgroupdetails = async () => {
    const apiData = { userId: userDetails?.id, token: userToken };
    try {
      await getAllRequestList(apiData).then(async (res: any) => {
        console.log(res)
        if (res?.status == true) {
          setNotification(res?.data)
          // setGetGroupDetails(res?.payload);
        }
      });
    } catch (error) {
      console.log('Details response: ', error);
    }
  };

  const GetgroupdetailsAdmin = async () => {
    const apiData = { userId: userDetails?.id, token: userToken };
    try {
      await getAllRequestListAdmin(apiData).then(async (res: any) => {
        console.log(res?.data, 'uuuuuu')
        if (res?.status == true) {
          setNotificationAdmin(res?.data)
          // setGetGroupDetails(res?.payload);
        }
      });
    } catch (error) {
      console.log('Details response: ', error);
    }
  };

  const JoinComunityApi = async (item: any, status: boolean) => {
    const data: any = {
      userId: userDetails?.id,
      token: userToken,
      id: item?.entity?.id,
      type: item?.type == "event" ? "events" : item?.type,
      isAccepted: status
    };
    try {
      const res = await requestJoinAcceptReject(data);
      if (res?.status == true) {
        const datas = { heading: 'login', message: res?.message };
        emitter.emit('alert', datas);
      } else {
        const data = {
          heading: 'failed',
          message: res?.message,
        };
        emitter.emit('alert', data);
      }
      console.log(res)
      Getgroupdetails()
      GetgroupdetailsAdmin()
    } catch (error) {
      console.log('Follow user response: ', error);
    }
  };

  const JoinComunityApiAdmin = async (item: any, status: boolean) => {
    const data: any = {
      userId: item?.user?.id,
      token: userToken,
      id: item?.entity?.id,
      type: item?.type == "event" ? "events" : item?.type,
      isAccepted: status
    };
    try {
      const res = await requestJoinAcceptReject(data);
      if (res?.status == true) {
        const datas = { heading: 'login', message: res?.message };
        emitter.emit('alert', datas);
      } else {
        const data = {
          heading: 'failed',
          message: res?.message,
        };
        emitter.emit('alert', data);
      }
      console.log(res)
      Getgroupdetails()
      GetgroupdetailsAdmin()
    } catch (error) {
      console.log('Follow user response: ', error);
    }
  };

  return (
    <View style={styles.mainContainer}>
      <ScrollView automaticallyAdjustContentInsets contentInsetAdjustmentBehavior='automatic' style={{ flex: 1, paddingHorizontal: ms(2), paddingTop: 20 }}>
        {
          notificationAdmin && (
            <>
              {
                notificationAdmin.map((item: any, index: number) => {
                  console.log(item)
                  return (
                    <View style={styles.listContainer}>
                      <View style={{flexDirection:'row', alignItems: 'center',gap: 10, flex: 1, paddingRight: 40}}>
                        <View style={{alignSelf: 'flex-start',marginTop: 5}}>
                        <ImgView height={35} width={35} url={item?.entity?.logo ? item?.entity?.logo : require('../../assets/img/noimage.png')} radius={35} dummy={item?.entity?.logo ? false : true} />
                        </View>
                        <AppText size={14} color='white' family='PoppinsMedium'>A request has come from the <AppText size={15} color='white' family='PoppinsBold'>{item?.entity?.name}</AppText>.</AppText>
                      </View>
                      <View style={{flexDirection:'row', alignItems: 'center',gap: 8, alignSelf: 'flex-start', marginTop: 5}}>
                        <TouchableOpacity style={[styles.buttonContainer, {backgroundColor: COLORS.blue}]} onPress={()=>JoinComunityApiAdmin(item, true)}>
                          <AppText size={14} color='white' family='PoppinsMedium'>Confirm</AppText>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.buttonContainer, {backgroundColor: COLORS.grey54}]} onPress={()=>JoinComunityApiAdmin(item, false)}>
                          <AppText size={14} color='white' family='PoppinsMedium'>Delete</AppText>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )
                })
              }
            </>
          )
        }
        {
          notification && (
            <>
              {
                notification.map((item: any, index: number) => {
                  console.log(item)
                  return (
                    <View style={styles.listContainer}>
                      <View style={{flexDirection:'row', alignItems: 'center',gap: 10, flex: 1, paddingRight: 40}}>
                        <View style={{alignSelf: 'flex-start',marginTop: 5}}>
                        <ImgView height={35} width={35} url={item?.entity?.image? item?.entity?.image : require('../../assets/img/noimage.png')} radius={35} dummy={item?.entity?.image ? false : true} />
                        </View>
                        <AppText size={14} color='white' family='PoppinsMedium'>A request has come from the <AppText size={15} color='white' family='PoppinsBold'>{item?.entity?.name}</AppText>.</AppText>
                      </View>
                      <View style={{flexDirection:'row', alignItems: 'center',gap: 8, alignSelf: 'flex-start', marginTop: 5}}>
                        <TouchableOpacity style={[styles.buttonContainer, {backgroundColor: COLORS.blue}]} onPress={()=>JoinComunityApi(item, true)}>
                          <AppText size={14} color='white' family='PoppinsMedium'>Confirm</AppText>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.buttonContainer, {backgroundColor: COLORS.grey54}]} onPress={()=>JoinComunityApi(item, false)}>
                          <AppText size={14} color='white' family='PoppinsMedium'>Delete</AppText>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )
                })
              }
            </>
          )
        }
      </ScrollView>
    </View>
  )
}

export default NotificationList